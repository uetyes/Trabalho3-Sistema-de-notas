package org.teiacoltec.poo.tp3;

import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;
import javax.crypto.Cipher;

public class Cripto{

    // Define que vou usar o algorítmo RSA, específico para criptografia assimétrica
    private static final String ALGORITMO = "RSA";
   
    // Implementar a geração de chaves públicas
    public static KeyPair gerarParDeChaves() throws Exception{
        KeyPairGenerator keyPairGenerator = KeyPairGenerator.getInstance(ALGORITMO); // Cria um gerador de chaves para trabalhar com o RSA
        keyPairGenerator.initialize(3072); // Tamanho de 3072 bytes
        return keyPairGenerator.generateKeyPair(); // Gera o par de chaves (uma pública e uma privada)
    }

    // Implementar a criptografia
    public static byte[] encriptar(String senha, PublicKey publicKey) throws Exception{
        Cipher cipher = Cipher.getInstance(ALGORITMO); // Procura uma implementação real de RSA. O objeto Cipher retorna esse algorítmo
        cipher.init(Cipher.ENCRYPT_MODE, publicKey); // Inicializa o algorítmo e passa a chave pública, dizendo que é para encriptar
        return cipher.doFinal(senha.getBytes()); // Converte a senha em bytes

    }

    public static String descriptar(byte [] senhaCriptografada, PrivateKey privateKey) throws Exception{
        Cipher cipher = Cipher.getInstance(ALGORITMO); // Procura a implementação dita anteriormente
        cipher.init(Cipher.DECRYPT_MODE, privateKey); // Agora em modo de decriptação, usa a chave privada relacionada a pública
        byte[] bytesConvertidos = cipher.doFinal(senhaCriptografada); // Aplica o algorítmo nos bytes criptografados e os transforma na senha original
        String senhaOriginal = new String(bytesConvertidos); // Converte os bytes para uma string
        return senhaOriginal; // Retorna a senha original
    }
}