package org.teiacoltec.poo.tp3.Excecoes;

public class AcessoNaoAutorizadoException extends Exception{
    public AcessoNaoAutorizadoException(){
        super("Erro ao realizar o login do usuario. A email ou senha não foi encontrado. Tente novamente.");
    }
}
