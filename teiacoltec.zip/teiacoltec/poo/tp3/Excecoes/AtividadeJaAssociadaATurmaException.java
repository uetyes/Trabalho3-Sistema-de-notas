package org.teiacoltec.poo.tp3.Excecoes;

import org.teiacoltec.poo.tp3.Turma.Atividade.Atividade;

public class AtividadeJaAssociadaATurmaException extends Exception{
    public AtividadeJaAssociadaATurmaException(Atividade atividade){
        super("Erro ao adicionar a ativividade " + atividade.getNome() + ". Essa atividade ja está associada a turma");
    }
}
