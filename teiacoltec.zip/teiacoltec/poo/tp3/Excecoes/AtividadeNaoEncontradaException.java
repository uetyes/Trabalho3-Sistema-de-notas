package org.teiacoltec.poo.tp3.Excecoes;

import org.teiacoltec.poo.tp3.Turma.Atividade.Atividade;

public class AtividadeNaoEncontradaException extends Exception{
    public AtividadeNaoEncontradaException(Atividade atividade)  {
        super("Erro ao remover a atividade " + atividade.getNome() + ". Essa atividade não foi encontrada ou não existe");
    }
}
