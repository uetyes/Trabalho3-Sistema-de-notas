package org.teiacoltec.poo.tp3.Excecoes;

import org.teiacoltec.poo.tp3.Turma.Atividade.Atividade;

public class AtividadeNaoPertenceATurmaException extends Exception{
    public AtividadeNaoPertenceATurmaException(Atividade atividade)  {
        super("Erro ao dar essa tarefa ao aluno, a atividade procurada não existe nessa turma.");
    }
}
