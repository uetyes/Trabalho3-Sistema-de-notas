package org.teiacoltec.poo.tp3.Excecoes;

public class CredenciaisInvalidasException extends Exception{
    public CredenciaisInvalidasException(){
        super("Erro ao realizar o login do usuario, email ou senha não foi encontrado. Tente novamente.");
    }
}
