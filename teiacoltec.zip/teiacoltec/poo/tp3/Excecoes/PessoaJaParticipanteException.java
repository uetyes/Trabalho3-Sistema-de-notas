package org.teiacoltec.poo.tp3.Excecoes;

import org.teiacoltec.poo.tp3.Pessoa;

public class PessoaJaParticipanteException extends Exception {
    public PessoaJaParticipanteException(Pessoa pessoa){
        super("Erro ao adicionar o participante " + pessoa.getNome() + ". Essa pessoa já existe nesta turma.");
    }
}
