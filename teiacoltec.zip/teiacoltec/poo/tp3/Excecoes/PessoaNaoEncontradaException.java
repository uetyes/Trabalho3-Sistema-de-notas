package org.teiacoltec.poo.tp3.Excecoes;

import org.teiacoltec.poo.tp3.Pessoa;

public class PessoaNaoEncontradaException extends Exception {
    public PessoaNaoEncontradaException(Pessoa pessoa){
        super("Erro ao remover o participante " + pessoa.getNome() + ". Essa pessoa não está ou não existe nesta turma");
    }
}
