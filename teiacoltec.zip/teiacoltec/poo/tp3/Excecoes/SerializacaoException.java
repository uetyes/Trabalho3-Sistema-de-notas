package org.teiacoltec.poo.tp3.Excecoes;

public class SerializacaoException extends Exception {
    public SerializacaoException() {
        super("Erro na serialização");
    }
}
