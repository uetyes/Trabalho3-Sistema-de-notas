package org.teiacoltec.poo.tp3.Excecoes;

public class TarefaJaCriadaException extends Exception{
    public TarefaJaCriadaException(){
        super("Erro ao criar dar a tarefa ao aluno, ele ja está a fazendo.");
    }
}
