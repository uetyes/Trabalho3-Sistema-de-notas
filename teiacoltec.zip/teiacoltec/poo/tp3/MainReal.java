package org.teiacoltec.poo.tp3;
import static org.teiacoltec.poo.tp3.Turma.Turma.listarSubturmas;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

import org.teiacoltec.poo.tp3.Excecoes.*;
import org.teiacoltec.poo.tp3.Turma.Turma;
import org.teiacoltec.poo.tp3.Turma.Atividade.Atividade;
import org.teiacoltec.poo.tp3.Turma.Atividade.Tarefa;
import org.teiacoltec.poo.tp3.Turma.ParticipantesDaTurma.*;

public class MainReal {
    static ArrayList<Turma> listaDeTurmas = new ArrayList<>();
    static ArrayList<Tarefa> listaTarefasDaPessoa = new ArrayList<>();
    static ArrayList<Pessoa> listaDePessoas = new ArrayList<>();

    public static void main(String[] args) throws PessoaNaoEncontradaException, ParseException, AtividadeJaAssociadaATurmaException, Exception {

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        Date dataNascP = sdf.parse("10/05/2000");
        Professor p1 = new Professor("111", "Jonas", dataNascP, "Jonas@gmail.com", "Rua Jatoba", "a2024952091", "Engenheiro Civil");
        p1.setSenha("123");
        p1.setLogin("Jonas");

        Date dataNascA = sdf.parse("13/07/2010");
        Aluno a1 = new Aluno("222", "Caique", dataNascA, "Caique@mgail.com", "Rua Andarilho", "a202495202019", "Eletronica");
        a1.setSenha("456");
        a1.setLogin("Caique");

        Date dataNascM = sdf.parse("20/10/2007");
        Monitor m1 = new Monitor("333", "Arthur", dataNascM, "ArthurLegal@mgail.com", "Rua Benjamim", "a202495201972", "Mecatronica");
        m1.setSenha("789");
        m1.setLogin("Arthur");

        listaDePessoas.add(p1);
        listaDePessoas.add(a1);
        listaDePessoas.add(m1);

        Autenticacao.autenticar("Jonas", "123", listaDePessoas);
        Autenticacao.autenticar("Caique", "456", listaDePessoas);
        Autenticacao.autenticar("Arthur", "789", listaDePessoas);


        // Salvar  
        try {
            Turma.salvarTurmasEmArquivo("turmas.dat");
            System.out.println("Turmas salvas com sucesso.");

            Atividade.salvarAtividadeArquivo("atividades.dat");
            System.out.println("Atividades salvas com sucesso.");

            Tarefa.salvaTarefaArquivo("tarefas.dat");
            System.out.println("Tarefas salvas com sucesso.");

            Aluno.salvaAlunosArquivo("alunos.dat");
            System.out.println("Alunos salvos com sucesso.");


            Professor.salvaProfessorArquivo("professores.dat");
            System.out.println("Professores salvos com sucesso.");


            Monitor.salvaMonitorArquivo("monitores.dat");
            System.out.println("Monitores salvos com sucesso.");


            // Execeção caso dê erro de salvamento de alguma classe
        } catch (Exception e) {
            System.err.println("Erro ao salvar as turmas: " + e.getMessage());

            System.err.println("Erro ao salvar as atividades: " + e.getMessage());

            System.err.println("Erro ao salvar as tarefas: " + e.getMessage());

            System.err.println("Erro ao salvar os alunos: " + e.getMessage());

            System.err.println("Erro ao salvar os professores: " + e.getMessage());

            System.err.println("Erro ao salvar os monitores: " + e.getMessage());
        }

        // Carregar 
        try {
            Turma.carregarTurmasDeArquivo("turmas.dat");
            System.out.println("Turmas carregadas com sucesso.");

            Atividade.carregarAtividadeArquivo("atividades.dat");
            System.out.println("Atividades carregadas com sucesso.");

            Tarefa.carregaTarefaArquivo("tarefas.dat");
            System.out.println("Tarefas carregadas com sucesso.");

            Aluno.carregaAlunosArquivo("alunos.dat");
            System.out.println("Alunos carregados com sucesso.");

            Professor.carregaProfessorArquivo("professores.dat");
            System.out.println("Professores carregados com sucesso.");

            Monitor.carregaMonitorArquivo("monitores.dat");
            System.out.println("Monitores carregados com sucesso.");

            // Execeção caso dê erro de carregamento de alguma classe
        } catch (Exception e) {
            System.err.println("Erro ao carregar as turmas: " + e.getMessage());

            System.err.println("Erro ao carregar as atividades: " + e.getMessage());

            System.err.println("Erro ao carregar as tarefas: " + e.getMessage());

            System.err.println("Erro ao carregar os alunos: " + e.getMessage());

            System.err.println("Erro ao carregar os professores: " + e.getMessage());

            System.err.println("Erro ao carregar os monitores: " + e.getMessage());
        }

        // Inicializa o scanner para entrada de dados
        Scanner scanner = new Scanner(System.in);


        // Menu principal
        // inicio!!!!


        while (true) {
            System.out.println("=-=-Inicio-=-=");
            System.out.println("1 - Cadastrar");
            System.out.println("2 - Logar");
            System.out.println("3 - Logout");
            System.out.println("0 - Sair");

            int opcaoInicial = scanner.nextInt();

            switch (opcaoInicial) {

                case 1:
                    cadastro();
                    break;
                case 2:
                    login();
                    break;
                case 3:
                    break;
                case 0: return;
                default:
                    System.out.println("Digite uma opcao valida");
                    break;
            }

        }
    }

    public static void cadastro() throws Exception {
        boolean cadastro = true;
        Scanner scanner = new Scanner(System.in);

        while (cadastro) {
            try {
                System.out.println("-=-=Cadastros-=-=");
                System.out.println("\n--- Criar novo participante ---");

                System.out.print("CPF do participante: ");
                String cpf = scanner.nextLine();

                System.out.print("Nome do participante: ");
                String nome = scanner.nextLine();

                System.out.print("Data de nascimento do participante (dd/MM/yyyy): ");
                Date nascimento = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

                System.out.print("E-mail do participante: ");
                String email = scanner.nextLine();

                System.out.print("Endereço do participante: ");
                String endereco = scanner.nextLine();

                System.out.print("Matrícula do participante: ");
                String matricula = scanner.nextLine();

                System.out.print("Curso/Formação do participante: ");
                String cursoOuFormacao = scanner.nextLine();

                System.out.print("Digite a senha do participante: ");
                String senha = scanner.nextLine();

                System.out.print("Digite o login do participante: ");
                String login = scanner.nextLine();

                System.out.println("\nSelecione o tipo de participante:");
                System.out.println("1 - Professor");
                System.out.println("2 - Monitor");
                System.out.println("3 - Aluno");
                System.out.print("Escolha: ");
                int tipoDeParticipanteCria = Integer.parseInt(scanner.nextLine());

                Pessoa novo = null;
                switch (tipoDeParticipanteCria) {
                    case 1:
                        novo = new Professor(cpf, nome, nascimento, email, endereco, matricula, cursoOuFormacao);
                        break;
                    case 2:
                        novo = new Monitor(cpf, nome, nascimento, email, endereco, matricula, cursoOuFormacao);
                        break;
                    case 3:
                        novo = new Aluno(cpf, nome, nascimento, email, endereco, matricula, cursoOuFormacao);
                        break;
                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                        continue; // volta pro while
                }

                // seta login e senha
                novo.setLogin(login);
                novo.setSenha(senha);

                // adiciona na lista de pessoas
                listaDePessoas.add(novo);

                System.out.println("Participante cadastrado com sucesso: " + novo.getNome());

            } catch (ParseException e) {
                System.out.println("Data inválida. Use o formato dd/MM/yyyy.");
            } catch (PessoaJaParticipanteException e) {
                System.out.println("Essa pessoa já está cadastrada.");
            }

            // Perguntar se o usuário deseja continuar
            System.out.print("\nDeseja adicionar outro participante? (s/n): ");
            String resposta = scanner.nextLine().trim().toLowerCase();
            if (!resposta.equals("s")) {
                cadastro = false;
            }
        }
    }



    public static void login() throws Exception {

        Pessoa usuarioLogado;
        Scanner sc = new Scanner(System.in);

        System.out.println("----LOGIN----");
        System.out.println("Digite o seu usuario: ");
        String nome = sc.nextLine();

        System.out.println("Digite a sua senha: ");
        String senha = sc.nextLine();

        usuarioLogado = Autenticacao.autenticar(nome,senha,listaDePessoas);

        boolean menu = true;
        while(menu) {

            if (usuarioLogado instanceof Professor) {

                System.out.println("-=-=Menu Professor-=-=");
                System.out.println("1 - Gerenciar turmas");
                System.out.println("2 - Voltar");

                int opcaoProfessor = sc.nextInt();

                switch (opcaoProfessor){
                    case 1: menuProfessor();
                        break;
                    case 2: menu = false;
                        break;
                }


            }
        }
    }

    public static void logout() throws Exception {
        Scanner scanner = new Scanner(System.in);

        System.out.println("-=-=Logout-=-=");
        System.out.println("Digite a senha: ");
        String senhaLogout = scanner.nextLine();

        System.out.println("Digite o login: ");
        String nomeLogout = scanner.nextLine();


    }

    public static void menuProfessor() throws Exception {
        Scanner scanner = new Scanner(System.in);
        boolean executandoProfessor = true;

        while(executandoProfessor){
            System.out.println("-=-=Menu de Professor-=-=");
            System.out.println("1 - Gerenciar turmas");
            System.out.println("0 - Voltar");

            int opcaoProfessor = scanner.nextInt();
            scanner.nextLine();

            switch (opcaoProfessor){
                case 1: menuInicialProfessor();
                    break;
                case 0: executandoProfessor = false;
                    break;
            }
        }
    }

    public static void menuInicialProfessor() throws Exception {
        Scanner scanner = new Scanner(System.in);

        while (true) {

            System.out.println("\n-----Menu principal-----");
            System.out.println("1 - Criar nova turma");
            System.out.println("2 - Listar turmas");
            System.out.println("3 - Atualizar turma");
            System.out.println("4 - Deletar turma");
            System.out.println("5 - Gerencia um turma");
            System.out.println("0 - Sair");

            int opcaoInicial = scanner.nextInt();
            scanner.nextLine();

            switch (opcaoInicial) {
                case 0:
                    return;
                case 1:
                    try {
                        System.out.println("---Criar nova turma---");
                        //(int ID, String nome, String descricao, Date inicio, Date fim, Turma turma_pai
                        System.out.println("ID da Turma:");
                        int id = scanner.nextInt();
                        scanner.nextLine(); //Limpar o /n


                        for (Turma turma : listaDeTurmas) {
                            if (turma.getID() == id) {
                                System.out.println("Já existe uma turma com esse ID. Escolha outro.");
                                return;
                            }
                        }

                        System.out.print("Nome da Turma: ");
                        String nome = scanner.nextLine();

                        System.out.print("Descrição: ");
                        String descricao = scanner.nextLine();

                        System.out.print("Data de Início (dd/MM/aaaa): ");
                        Date inicio = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

                        System.out.print("Data de Fim (dd/MM/aaaa): ");
                        Date fim = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

                        Turma novaTurma = new Turma(id, nome, descricao, inicio,fim);
                        listaDeTurmas.add(novaTurma);

                    } catch (ParseException e) {
                        System.out.println("Formato de data inválido. Deve ser: dd/MM/aaaa");
                        break;
                    } catch (NumberFormatException e) {
                        System.out.println("ID inválido. Deve ser um número inteiro.");
                        break;
                    }
                    break;
                case 2:
                    if(listaDeTurmas.isEmpty()){
                        System.out.println("Não existe nenhuma turma cadastrada");
                        break;
                    }
                    for(Turma turmas : listaDeTurmas){
                        imprimirInformacoes(turmas);
                    }
                    break;
                case 3:
                    System.out.println("\n---Atualizar turma---");
                    System.out.println("Digite o ID da turma que deseja atualizar:");

                    int idTurmaEscolhida = scanner.nextInt();
                    scanner.nextLine(); // Limpar o \n pendente

                    boolean turmaEncontrada = false;

                    for (Turma turmas : listaDeTurmas) {
                        if (turmas.getID() == idTurmaEscolhida) {
                            turmaEncontrada = true;

                            System.out.println("Digite o novo nome da turma (Enter para não mudar): ");
                            String novoNome = scanner.nextLine();
                            if (!novoNome.isBlank()) {
                                turmas.setNome(novoNome);
                            }

                            System.out.println("Digite a nova descrição da turma (Enter para não mudar): ");
                            String novaDescricao = scanner.nextLine();
                            if (!novaDescricao.isBlank()) {
                                turmas.setDesc(novaDescricao);
                            }

                            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

                            System.out.println("Digite a nova data de início da turma (Enter para não mudar): ");
                            String novaDataInicioStr = scanner.nextLine();
                            if (!novaDataInicioStr.isBlank()) {
                                try {
                                    Date novaDataInicio = sdf.parse(novaDataInicioStr);
                                    turmas.setDataInicio(novaDataInicio);
                                } catch (ParseException e) {
                                    System.out.println("Formato de data inválido. A atualização não foi bem sucedida.");
                                    return;
                                }
                            }

                            System.out.println("Digite a nova data de fim da turma (Enter para não mudar): ");
                            String novaDataFimStr = scanner.nextLine();
                            if (!novaDataFimStr.isBlank()) {
                                try {
                                    Date novaDataFim = sdf.parse(novaDataFimStr);
                                    turmas.setDataFim(novaDataFim);
                                } catch (ParseException e) {
                                    System.out.println("Formato de data inválido. A atualização não foi bem sucedida.");
                                    return;
                                }
                            }

                            break; // para sair do for após encontrar e atualizar
                        }
                    }

                    if (!turmaEncontrada) {
                        System.out.println("Turma com ID " + idTurmaEscolhida + " não encontrada.");
                    }

                    break;

                case 4:
                    System.out.println("\n---Deletar turma---");
                    System.out.println("Digite o ID da turma que deseja deletar");
                    int idTurmaEscolhidaDeletar = Integer.parseInt(scanner.nextLine());

                    boolean removido = false;
                    for (int i = 0; i < listaDeTurmas.size(); i++) {
                        Turma turma = listaDeTurmas.get(i);
                        if (turma.getID() == idTurmaEscolhidaDeletar) {
                            listaDeTurmas.remove(i);
                            removido = true;
                            break; // sai do loop após remover
                        }
                    }

                    if (!removido) {
                        System.out.println("Turma com ID " + idTurmaEscolhidaDeletar + " não encontrada.");
                    }
                    break;
                case 5:
                    int idTurmaEscolhidaMenu;
                    boolean encontrou = false;

                    System.out.println("Digite o ID da turma que deseja gerenciar:");
                    idTurmaEscolhidaMenu = scanner.nextInt();
                    scanner.nextLine();

                    for(Turma turmas : listaDeTurmas){
                        if(turmas.getID() == idTurmaEscolhidaMenu){
                            menuDeTurma(turmas);
                            encontrou = true;
                        }
                    }
                    if(!encontrou){
                        System.out.println("Nao existe turma com esse ID" );
                    }

                    break;
                default:
                    System.out.println("Opcao invalida.");
                    break;
            }

        }
    }

    public static void menuDeTurma(Turma turma) throws PessoaNaoEncontradaException, ParseException, AtividadeJaAssociadaATurmaException, Exception{
        Scanner scanner = new Scanner(System.in);
        boolean executando = true;
        int opcaoEscolhidaMenuTurma;

        while(executando) {

            System.out.println("\n-----Menu da turma: " + turma.getNome() + " -----");
            System.out.println("1 - Listar participantes");
            System.out.println("2 - Gerenciar subTurmas");
            System.out.println("3 - Gerenciar atividades");
            System.out.println("0 - Voltar ao menu anterior");

            opcaoEscolhidaMenuTurma = scanner.nextInt();
            scanner.nextLine();

            switch (opcaoEscolhidaMenuTurma){
                case 0: executando = false;
                    break;
                case 1:  System.out.println("Qual o tipo de participante que voce deseja listar?");
                    System.out.println("1 - Professor");
                    System.out.println("2 - Monitor");
                    System.out.println("3 - Aluno");
                    System.out.println("4 - Todos");

                    int tipoDeParticipanteLista = scanner.nextInt();
                    scanner.nextLine();

                    switch (tipoDeParticipanteLista) {
                        case 1:
                            for(Professor professor : turma.obtemListaProfessores(true))
                            {
                                imprimirInformacoes(professor);
                                System.out.println("*=*=*");
                            }
                            break;
                        case 2:
                            for(Monitor monitor : turma.obtemListaMonitores(true))
                            {
                                imprimirInformacoes(monitor);
                                System.out.println("*=*=*");
                            }
                            break;
                        case 3:
                            for(Aluno aluno : turma.obtemListaAlunos(true))
                            {
                                imprimirInformacoes(aluno);
                                System.out.println("*=*=*");
                            }
                            break;
                        case 4:
                            for(Pessoa pessoa : turma.obtemListaParticipantes())
                            {
                                imprimirInformacoes(pessoa);
                                System.out.println("*=*=*");
                            }
                            break;
                        default:
                            System.out.println("Insira uma opcao valida");
                            break;
                    }
                    break;
                case 2: subTurma(turma);
                    break;
                case 3: menuAtividades(turma);
                    break;
                default:System.out.println("Insira uma opcao valida");

            }
        }
    }

    public static void menuAtividades(Turma turma) throws ParseException, AtividadeJaAssociadaATurmaException {
        Scanner scanner = new Scanner(System.in);

        boolean executandoAtividade = true;
        int opcaoInicalAtividade;

        while(executandoAtividade){
            System.out.println("\n-----Menu de atividades-----");
            System.out.println("1 - Criar nova atividade");
            System.out.println("2 - Listar atividades");
            System.out.println("3 - Atualizar atividade");
            System.out.println("4 - Desassociar atividade");
            System.out.println("0 - Voltar ao menu anterior");

            opcaoInicalAtividade = scanner.nextInt();
            scanner.nextLine();
            //int ID, String nome, String descricao, Date inicio, Date fim, float valor
            switch (opcaoInicalAtividade){
                case 0: executandoAtividade = false;
                    break;
                case 1:
                    try {
                        System.out.println("ID da atividade: ");
                        int id = scanner.nextInt();
                        scanner.nextLine();

                        boolean jaExisteAtividade = false;
                        for (Atividade atividade : turma.obtemAtividadesDaTurma(true)) {
                            if (atividade != null && atividade.getID() == id) {
                                jaExisteAtividade = true;
                                break;
                            }
                        }

                        if (jaExisteAtividade) {
                            System.out.println("Ja existe uma atividade com esse ID");
                            break;
                        }

                        System.out.print("Nome da atividade: ");
                        String nome = scanner.nextLine();

                        System.out.println("Descricao da atividade: ");
                        String descricao = scanner.nextLine();

                        System.out.println("Data de inicio da atividade: ");
                        Date inicio = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

                        System.out.println("Data de finalizacao da atividade: ");
                        Date fim = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

                        System.out.println("Valor máximo da atividade:");
                        float valor = scanner.nextFloat();
                        scanner.nextLine();

                        turma.associaAtividade(new Atividade(id, nome, descricao, inicio, fim, valor));
                    } catch(ParseException ex)
                    {
                        System.err.println("Formato de data inválido");
                    }
                    catch(AtividadeJaAssociadaATurmaException ex)
                    {
                        System.err.println("Esta atividade já está na turma");
                    }
                    break;
                case 2:
                    String opcao;
                    boolean temAtividade = false;
                    System.out.println("Voce deseja ver todas as atividades que a turma ja teve (t) ou somente as que estao dentro do prazo (p) (t/p)");
                    opcao = scanner.nextLine();

                    if(turma.obtemAtividadesDaTurma(true).length > 0){
                        temAtividade = true;
                    }
                    switch (opcao) {
                        case "T":
                        case "t":
                            Atividade[] todas = turma.obtemAtividadesDaTurma(true);
                            for (Atividade atividade : todas) {
                                imprimirInformacoes(atividade);
                            }
                            break;
                        case "P":
                        case "p":
                            try {
                                System.out.println("Digite o prazo da atividade que voce deseja listar");
                                System.out.println("Inicio: ");
                                Date inicio = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());
                                System.out.println("Fim: ");
                                Date fim = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

                                Atividade[] noPrazo = turma.obtemAtividadesDaTurma(true, inicio, fim);
                                for (Atividade atividade : noPrazo) {
                                    imprimirInformacoes(atividade);
                                }
                            } catch (ParseException e) {
                                System.out.println("Erro: Formato de data inválido. Use dd/MM/yyyy.");
                            }
                            break;

                        default:
                            System.out.println("Opcao invalida digite 't' ou 'p' ");
                            break;
                    }

                    if(!temAtividade){
                        System.out.println("Nao tem atividades");
                    }
                    break;

                case 3:
                    System.out.println("Digite o ID da atividade que deseja atualizar:");
                    int idAtualizar = scanner.nextInt();
                    scanner.nextLine();

                    Atividade atividadeSelecionada = null;
                    for (Atividade atividade : turma.obtemAtividadesDaTurma(true)) {
                        if (atividade.getID() == idAtualizar) {
                            atividadeSelecionada = atividade;
                            break;
                        }
                    }

                    if (atividadeSelecionada == null) {
                        System.out.println("Atividade com esse ID não encontrada.");
                        break;
                    }

                    System.out.println("Atualizando atividade: " + atividadeSelecionada.getNome());

                    System.out.print("Novo nome (Enter para manter): ");
                    String novoNome = scanner.nextLine();
                    if (!novoNome.isBlank()) {
                        atividadeSelecionada.setNome(novoNome);
                    }

                    System.out.print("Nova descrição (Enter para manter): ");
                    String novaDescricao = scanner.nextLine();
                    if (!novaDescricao.isBlank()) {
                        atividadeSelecionada.setDescricao(novaDescricao);
                    }

                    System.out.print("Nova data de início (dd-MM-yyyy) (Enter para manter): ");
                    String novaDataInicioStr = scanner.nextLine();
                    if (!novaDataInicioStr.isBlank()) {
                        try {
                            Date novaDataInicio = new SimpleDateFormat("dd-MM-yyyy").parse(novaDataInicioStr);
                            atividadeSelecionada.setInicio(novaDataInicio);
                        } catch (ParseException e) {
                            System.out.println("Data inválida. Atualização de início ignorada.");
                        }
                    }

                    System.out.print("Nova data de fim (dd-MM-yyyy) (Enter para manter): ");
                    String novaDataFimStr = scanner.nextLine();
                    if (!novaDataFimStr.isBlank()) {
                        try {
                            Date novaDataFim = new SimpleDateFormat("dd-MM-yyyy").parse(novaDataFimStr);
                            atividadeSelecionada.setFim(novaDataFim);
                        } catch (ParseException e) {
                            System.out.println("Data inválida. Atualização de fim ignorada.");
                        }
                    }

                    System.out.print("Novo valor máximo da atividade (digite -1 para manter): ");
                    String valorStr = scanner.nextLine();
                    if (!valorStr.isBlank()) {
                        try {
                            float novoValor = Float.parseFloat(valorStr);
                            if (novoValor >= 0) {
                                atividadeSelecionada.setValor(novoValor);
                            }
                        } catch (NumberFormatException e) {
                            System.out.println("Valor inválido. Atualização do valor ignorada.");
                        }
                    }
                    break;
                case 4:
                    int idAtividadeDeleta;
                    System.out.println("Digite a atividade que deseja desassociar da turma");
                    idAtividadeDeleta = scanner.nextInt();

                    Atividade atividadeSelecionadaDe = null;
                    for (Atividade atividade : turma.obtemAtividadesDaTurma(true)) {
                        if (atividade.getID() == idAtividadeDeleta) {
                            atividadeSelecionadaDe = atividade;
                            break;
                        }
                    }

                    if (atividadeSelecionadaDe == null) {
                        System.out.println("Atividade com esse ID não encontrada.");
                        break;
                    }

                    try{
                        turma.desassociaAtividade(atividadeSelecionadaDe);
                    } catch (AtividadeNaoEncontradaException e) {
                        throw new RuntimeException(e);
                    }
                    break;

                default:
                    System.out.println("Opcao invalida");
                    break;

            }
        }
    }

    public static void tarefasAlunos(Turma turma) throws ParseException {
        Scanner scanner = new Scanner(System.in);

        boolean executandoTarefa = true;

        while (executandoTarefa) {
            System.out.println("----- Menu de Tarefa -----");
            System.out.println("1 - Criar nova tarefa");
            System.out.println("2 - Listar todas as tarefas");
            System.out.println("3 - Listar tarefas de um aluno");
            System.out.println("4 - Lançar nota de uma tarefa");
            System.out.println("0 - Voltar ao menu anterior");
            System.out.print("Escolha: ");
            int escolhaTarefa = Integer.parseInt(scanner.nextLine());

            switch (escolhaTarefa) {
                case 0:
                    executandoTarefa = false;
                    break;

                case 1: // Criar nova tarefa
                    if (turma.obtemListaAlunos(true).length == 0) {
                        System.out.println("Não há alunos cadastrados na turma.");
                        break;
                    }
                    if (turma.obtemAtividadesDaTurma(true).length == 0) {
                        System.out.println("Não há atividades cadastradas na turma.");
                        break;
                    }

                    System.out.print("ID da tarefa: ");
                    int idTarefa = Integer.parseInt(scanner.nextLine());

                    // Escolha do aluno
                    System.out.println("Alunos disponíveis:");
                    for (Aluno aluno : turma.obtemListaAlunos(true)) {
                        System.out.println("Nome: " + aluno.getNome() + " | CPF: " + aluno.getCPF());
                    }
                    System.out.print("Digite o CPF do aluno: ");
                    String cpfAluno = scanner.nextLine();
                    Aluno alunoSelecionado = null;
                    for (Aluno aluno : turma.obtemListaAlunos(true)) {
                        if (aluno.getCPF().equals(cpfAluno)) {
                            alunoSelecionado = aluno;
                            break;
                        }
                    }
                    if (alunoSelecionado == null) {
                        System.out.println("Aluno não encontrado.");
                        break;
                    }

                    // Escolha da atividade
                    System.out.println("Atividades disponíveis:");
                    for (Atividade atividade : turma.obtemAtividadesDaTurma(true)) {
                        System.out.println("ID: " + atividade.getID() + " | Nome: " + atividade.getNome());
                    }
                    System.out.print("Digite o ID da atividade: ");
                    int idAtividade = Integer.parseInt(scanner.nextLine());
                    Atividade atividadeSelecionada = null;
                    for (Atividade atividade : turma.obtemAtividadesDaTurma(true)) {
                        if (atividade.getID() == idAtividade) {
                            atividadeSelecionada = atividade;
                            break;
                        }
                    }
                    if (atividadeSelecionada == null) {
                        System.out.println("Atividade não encontrada.");
                        break;
                    }

                    // Verifica se já existe tarefa para este aluno + atividade
                    ArrayList<Tarefa> listaTarefas = turma.tarefas; // Lista de tarefas da turma
                    Atividade finalAtividadeSelecionada = atividadeSelecionada;
                    Aluno finalAlunoSelecionado = alunoSelecionado;
                    boolean tarefaExistente = listaTarefas.stream()
                            .anyMatch(t -> t.getAluno().equals(finalAlunoSelecionado) &&
                                    t.getAtividade().equals(finalAtividadeSelecionada));
                    if (tarefaExistente) {
                        System.out.println("Erro: Já existe uma tarefa para esse aluno e essa atividade.");
                        break;
                    }

                    System.out.print("Nota da tarefa (0 a " + atividadeSelecionada.getValor() + "): ");
                    float nota = Float.parseFloat(scanner.nextLine());
                    if (nota < 0 || nota > atividadeSelecionada.getValor()) {
                        System.out.println("Nota inválida.");
                        break;
                    }

                    // Cria e adiciona a tarefa
                    Tarefa novaTarefa = new Tarefa(idTarefa, alunoSelecionado, atividadeSelecionada, nota);
                    turma.adicionaTarefa(novaTarefa);
                    System.out.println("Tarefa adicionada com sucesso!");
                    break;

                case 2: // Listar todas as tarefas
                    if (turma.tarefas.isEmpty()) {
                        System.out.println("Nenhuma tarefa cadastrada.");
                        break;
                    }
                    System.out.println("Todas as tarefas:");
                    for (Tarefa t : turma.tarefas) {
                        imprimirInformacoes(t);
                    }
                    break;

                case 3: // Listar tarefas de um aluno específico
                    System.out.print("Digite o CPF do aluno: ");
                    String cpfAlunoLista = scanner.nextLine();
                    Aluno alunoLista = null;
                    for (Aluno aluno : turma.obtemListaAlunos(true)) {
                        if (aluno.getCPF().equals(cpfAlunoLista)) {
                            alunoLista = aluno;
                            break;
                        }
                    }
                    if (alunoLista == null) {
                        System.out.println("Aluno não encontrado.");
                        break;
                    }
                    ArrayList<Tarefa> tarefasDoAluno = new ArrayList<>();
                    for (Tarefa t : turma.tarefas) {
                        if (t.getAluno().equals(alunoLista)) {
                            tarefasDoAluno.add(t);
                        }
                    }
                    if (tarefasDoAluno.isEmpty()) {
                        System.out.println("Aluno não possui tarefas.");
                        break;
                    }
                    System.out.println("Tarefas do aluno " + alunoLista.getNome() + ":");
                    for (Tarefa t : tarefasDoAluno) {
                        imprimirInformacoes(t);
                    }
                    break;

                case 4: // Lançar nota de uma tarefa
                    System.out.print("Digite o CPF do aluno: ");
                    String cpfAlunoNota = scanner.nextLine();
                    Aluno alunoNota = null;
                    for (Aluno aluno : turma.obtemListaAlunos(true)) {
                        if (aluno.getCPF().equals(cpfAlunoNota)) {
                            alunoNota = aluno;
                            break;
                        }
                    }
                    if (alunoNota == null) {
                        System.out.println("Aluno não encontrado.");
                        break;
                    }

                    // Filtra as tarefas desse aluno
                    ArrayList<Tarefa> tarefasAlunoNota = new ArrayList<>();
                    for (Tarefa t : turma.tarefas) {
                        if (t.getAluno().equals(alunoNota)) {
                            tarefasAlunoNota.add(t);
                        }
                    }
                    if (tarefasAlunoNota.isEmpty()) {
                        System.out.println("Aluno não possui tarefas.");
                        break;
                    }

                    System.out.println("Tarefas do aluno:");
                    for (Tarefa t : tarefasAlunoNota) {
                        imprimirInformacoes(t);
                    }

                    System.out.print("Digite o ID da tarefa que deseja atualizar a nota: ");
                    int idTarefaNota = Integer.parseInt(scanner.nextLine());
                    Tarefa tarefaParaAtualizar = null;
                    for (Tarefa t : tarefasAlunoNota) {
                        if (t.getID() == idTarefaNota) {
                            tarefaParaAtualizar = t;
                            break;
                        }
                    }
                    if (tarefaParaAtualizar == null) {
                        System.out.println("Tarefa não encontrada.");
                        break;
                    }

                    System.out.print("Nova nota (0 a " + tarefaParaAtualizar.getAtividade().getValor() + "): ");
                    float novaNota = Float.parseFloat(scanner.nextLine());
                    if (novaNota < 0 || novaNota > tarefaParaAtualizar.getAtividade().getValor()) {
                        System.out.println("Nota inválida.");
                        break;
                    }
                    tarefaParaAtualizar.setNota(novaNota);
                    System.out.println("Nota atualizada com sucesso!");
                    break;

                default:
                    System.out.println("Opção inválida.");
                    break;
            }
        }
    }



    public static void menuParticipantes(Turma turma) throws PessoaNaoEncontradaException, ParseException, Exception {
        Scanner scanner = new Scanner(System.in);
        int opcaoParticipantes;
        boolean executandoParticipantes = true;

        while(executandoParticipantes) {
            System.out.println("\n-----Menu da turma de participantes-----");
            System.out.println("1 - Criar novo participante");
            System.out.println("2 - Listar participantes");
            System.out.println("3 - Atualizar participante");
            System.out.println("4 - Deletar participante");
            System.out.println("0 - Voltar ao menu anterior");

            opcaoParticipantes = scanner.nextInt();
            scanner.nextLine();

            boolean executaCriando = true;
            boolean executaCriandoSub = true;
            int tipoDeParticipanteCria;
            int tipoDeParticipanteLista;

                switch (opcaoParticipantes) {
                    case 0:
                        executandoParticipantes = false;
                        break;
                    case 1:
                        boolean continuarCriando = true;

                        while (continuarCriando) {
                            try {
                                System.out.println("\n--- Criar novo participante ---");

                                System.out.print("CPF do participante: ");
                                String cpf = scanner.nextLine();

                                System.out.print("Nome do participante: ");
                                String nome = scanner.nextLine();

                                System.out.print("Data de nascimento do participante (dd/MM/yyyy): ");
                                Date nascimento = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

                                System.out.print("E-mail do participante: ");
                                String email = scanner.nextLine();

                                System.out.print("Endereço do participante: ");
                                String endereco = scanner.nextLine();

                                System.out.print("Matrícula do participante: ");
                                String matricula = scanner.nextLine();

                                System.out.print("Curso/Formação do participante: ");
                                String cursoOuFormacao = scanner.nextLine();

                                System.out.println("\nSelecione o tipo de participante:");
                                System.out.println("1 - Professor");
                                System.out.println("2 - Monitor");
                                System.out.println("3 - Aluno");
                                System.out.print("Escolha: ");

                                tipoDeParticipanteCria = Integer.parseInt(scanner.nextLine());

                                switch (tipoDeParticipanteCria) {
                                    case 1:
                                        turma.adicionarProfessor(new Professor(cpf, nome, nascimento, email, endereco, matricula, cursoOuFormacao));
                                        break;
                                    case 2:
                                        turma.adicionarMonitor(new Monitor(cpf, nome, nascimento, email, endereco, matricula, cursoOuFormacao));
                                        break;
                                    case 3:
                                        turma.adicionarAlunos(new Aluno(cpf, nome, nascimento, email, endereco, matricula, cursoOuFormacao));
                                        break;
                                    default:
                                        System.out.println("Opção inválida. Tente novamente.");
                                        break;
                                }

                            } catch (ParseException e) {
                                System.out.println("Data inválida. Use o formato dd/MM/yyyy.");
                            } catch (PessoaJaParticipanteException e) {
                                System.out.println("Essa pessoa já está cadastrada na turma.");
                            }

                            // Perguntar se o usuário deseja continuar
                            System.out.print("\nDeseja adicionar outro participante? (s/n): ");
                            String resposta = scanner.nextLine().trim().toLowerCase();
                            if (!resposta.equals("s")) {
                                continuarCriando = false;
                            }
                        }
                        break;

                    case 2:
                        System.out.println("Qual o tipo de participante que voce deseja listar?");
                        System.out.println("1 - Professor");
                        System.out.println("2 - Monitor");
                        System.out.println("3 - Aluno");
                        System.out.println("4 - Todos");

                        tipoDeParticipanteLista = scanner.nextInt();
                        scanner.nextLine();

                        switch (tipoDeParticipanteLista) {
                            case 1:
                                for(Professor professor : turma.obtemListaProfessores(true))
                                {
                                    imprimirInformacoes(professor);
                                   System.out.println("*=*=*");
                                }
                                break;
                            case 2:
                                for(Monitor monitor : turma.obtemListaMonitores(true))
                                {
                                    imprimirInformacoes(monitor);
                                    System.out.println("*=*=*");
                                }
                                break;
                            case 3:
                                for(Aluno aluno : turma.obtemListaAlunos(true))
                                {
                                    imprimirInformacoes(aluno);
                                    System.out.println("*=*=*");
                                }
                                break;
                            case 4:
                                for(Pessoa pessoa : turma.obtemListaParticipantes())
                                {
                                    imprimirInformacoes(pessoa);
                                    System.out.println("*=*=*");
                                }
                                break;
                            default:
                                System.out.println("Insira uma opcao valida");
                                break;
                        }
                        break;
                    case 3:
                        System.out.println("Digite o CPF do partcipante que deseja atualizar");
                        String cpfBusca = scanner.nextLine();

                            Pessoa participanteEncontrado = null;
                        for (Pessoa pessoa : turma.obtemListaParticipantes()) {
                            if (Objects.equals(pessoa.getCPF(), cpfBusca)) {
                                participanteEncontrado = pessoa;
                                break;
                            }
                        }

                        if (participanteEncontrado == null) {
                            System.out.println("Participante nao econtrado");
                            break;
                        }
                        System.out.println("Atualizando dados do participante: " + participanteEncontrado.getNome());
                        System.out.print("Novo nome (Enter para manter): ");
                        String novoNome = scanner.nextLine();
                        if (!novoNome.isBlank()) {
                            participanteEncontrado.setNome(novoNome);
                        }

                        System.out.print("Novo email (Enter para manter): ");
                        String novoEmail = scanner.nextLine();
                        if (!novoEmail.isBlank()) {
                            participanteEncontrado.setEmail(novoEmail);
                        }

                        System.out.print("Novo endereço (Enter para manter): ");
                        String novoEndereco = scanner.nextLine();
                        if (!novoEndereco.isBlank()) {
                            participanteEncontrado.setEndereco(novoEndereco);
                        }

                        System.out.print("Nova data de nascimento (dd/MM/yyyy) (Enter para manter): ");
                        String novaDataStr = scanner.nextLine();
                        if (!novaDataStr.isBlank()) {
                            try {
                                Date novaData = new SimpleDateFormat("dd/MM/yyyy").parse(novaDataStr);
                                participanteEncontrado.setNascimento(novaData);
                            } catch (ParseException e) {
                                System.out.println("Data inválida. Nenhuma alteração feita na data.");
                            }
                        }

                        if (participanteEncontrado instanceof Aluno aluno) {
                            System.out.print("Nova matrícula (Enter para manter): ");
                            String novaMatricula = scanner.nextLine();
                            if (!novaMatricula.isBlank()) aluno.setFormacaoOuCurso(novaMatricula);

                            System.out.print("Novo curso (Enter para manter): ");
                            String novoCurso = scanner.nextLine();
                            if (!novoCurso.isBlank()) aluno.setFormacaoOuCurso(novoCurso);
                        } else if (participanteEncontrado instanceof Professor professor) {
                            System.out.print("Nova matrícula (Enter para manter): ");
                            String novaMatricula = scanner.nextLine();
                            if (!novaMatricula.isBlank()) professor.setFormacaoOuCurso(novaMatricula);

                            System.out.print("Nova formação (Enter para manter): ");
                            String novaFormacao = scanner.nextLine();
                            if (!novaFormacao.isBlank()) professor.setFormacaoOuCurso(novaFormacao);
                        } else if (participanteEncontrado instanceof Monitor monitor) {
                            System.out.print("Nova matrícula (Enter para manter): ");
                            String novaMatricula = scanner.nextLine();
                            if (!novaMatricula.isBlank()) monitor.setFormacaoOuCurso(novaMatricula);

                            System.out.print("Novo curso (Enter para manter): ");
                            String novoCurso = scanner.nextLine();
                            if (!novoCurso.isBlank()) monitor.setFormacaoOuCurso(novoCurso);
                        }

                        System.out.println("Participante atualizado com sucesso!");
                        break;

                    case 4:
                        System.out.println("Qual o tipo de participante que voce deseja remover?");
                        System.out.println("1 - Professor");
                        System.out.println("2 - Monitor");
                        System.out.println("3 - Aluno");

                        int opcaoRemover;
                        opcaoRemover = scanner.nextInt();
                        scanner.nextLine();

                        String professorRemover;
                        String monitorRemover;
                        String alunoRemover;

                        switch (opcaoRemover){
                            case 1:
                                System.out.println("Digite o cpf do professor que deseja remover");
                                professorRemover = scanner.nextLine();
                                for(Professor professor : turma.obtemListaProfessores(true)){
                                    if(Objects.equals(professor.getCPF(), professorRemover)){
                                        turma.removerProfessor(professor);
                                    }
                                }
                                break;
                            case 2:
                                System.out.println("Digite o cpf do monitor que deseja remover");
                                monitorRemover = scanner.nextLine();
                                for(Monitor monitor : turma.obtemListaMonitores(true)){
                                    if(Objects.equals(monitor.getCPF(), monitorRemover)){
                                        turma.removerMonitor(monitor);
                                    }
                                }
                                break;
                            case 3:
                                System.out.println("Digite o cpf do aluno que deseja remover");
                                alunoRemover = scanner.nextLine();
                                for(Aluno aluno : turma.obtemListaAlunos(true)){
                                    if(Objects.equals(aluno.getCPF(), alunoRemover)){
                                        turma.removerAluno(aluno);
                                    }
                                }
                                break;
                            default:
                                System.out.println("Insira uma opcao valida.");
                                break;
                        }
                        break;
                    case 5:
                        tarefasAlunos(turma);
                        break;


                }

        }
    }

    public static void subTurma(Turma turma) throws ParseException, PessoaNaoEncontradaException, AtividadeJaAssociadaATurmaException, Exception {

        Scanner scanner = new Scanner(System.in);

        int opcaoSubturma;
        int idSubturmaAtualiza;
        int idSubTurmaDeleta;
        boolean executaSubturma = true;
        while(executaSubturma)
        {
            System.out.println("Escreva o que quer fazer:");
            System.out.println("1 - Criar nova subTurma para a turma " + turma.getNome());
            System.out.println("2 - Atualizar uma subTurma");
            System.out.println("3 - Listar uma subTurma");
            System.out.println("4 - Deletar uma subTurma");
            System.out.println("5 - Gerencia subTurmas");
            System.out.println("0 - Voltar ao menu anterior\n");

            opcaoSubturma = scanner.nextInt();
            scanner.nextLine();

            switch (opcaoSubturma){
                case 0: executaSubturma = false;
                    break;
                case 1:
                    System.out.println("ID da nova subturma:");
                    int id = Integer.parseInt(scanner.nextLine());

                    System.out.print("Nome da subturma: ");
                    String nome = scanner.nextLine();

                    System.out.print("Descrição: ");
                    String descricao = scanner.nextLine();

                    System.out.print("Data de Início (dd/MM/yyyy): ");
                    Date inicio = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

                    System.out.print("Data de Fim (dd/MM/yyyy): ");
                    Date fim = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());


                    Turma novaSubturma = new Turma(id, nome, descricao, inicio, fim, turma);

                    turma.associaTurma(novaSubturma);

                    break;
                case 2:
                    System.out.println("Digite o ID da subTurma que voce deseja atualizar:");
                    idSubturmaAtualiza = scanner.nextInt();
                    scanner.nextLine();

                    Turma subTurmaSelecionada = null;
                    for (Turma subTurma : turma.getSubturmas()) {
                        if (subTurma != null && subTurma.getID() == idSubturmaAtualiza) {
                            subTurmaSelecionada = subTurma;
                            break;
                        }
                    }
                    if(subTurmaSelecionada == null){
                        System.out.println("Nao existe subTurma com essse ID");
                        return;
                    }
                    System.out.print("Novo nome da subturma (Enter para manter): ");
                    String novoNome = scanner.nextLine();
                    if (!novoNome.isBlank()) {
                        subTurmaSelecionada.setNome(novoNome);
                    }

                    System.out.print("Nova descrição da subturma (Enter para manter): ");
                    String novaDescricao = scanner.nextLine();
                    if (!novaDescricao.isBlank()) {
                        subTurmaSelecionada.setDesc(novaDescricao);
                    }

                    System.out.print("Nova data de início (dd/MM/yyyy) (Enter para manter): ");
                    String novaDataInicioStr = scanner.nextLine();
                    if (!novaDataInicioStr.isBlank()) {
                        try {
                            Date novaDataInicio = new SimpleDateFormat("dd/MM/yyyy").parse(novaDataInicioStr);
                            subTurmaSelecionada.setDataInicio(novaDataInicio);
                        } catch (ParseException e) {
                            System.out.println("Data inválida. Atualização de data de início ignorada.");
                        }
                    }

                    System.out.print("Nova data de fim (dd/MM/yyyy) (Enter para manter): ");
                    String novaDataFimStr = scanner.nextLine();
                    if (!novaDataFimStr.isBlank()) {
                        try {
                            Date novaDataFim = new SimpleDateFormat("dd/MM/yyyy").parse(novaDataFimStr);
                            subTurmaSelecionada.setDataFim(novaDataFim);
                        } catch (ParseException e) {
                            System.out.println("Data inválida. Atualização de data de fim ignorada.");
                        }
                    }
                    break;
                case 3:
                    listarSubturmas(turma);
                    break;
                case 4:
                    System.out.println("Digite o ID da subturma que deseja deletar:");
                    idSubTurmaDeleta = scanner.nextInt();
                    scanner.nextLine();

                    boolean removida = false;
                    Turma[] subturmasArray = turma.getSubturmas();
                    for (int i = 0; i < subturmasArray.length; i++) {
                        if (subturmasArray[i] != null && subturmasArray[i].getID() == idSubTurmaDeleta) {
                            turma.removeSubturma(subturmasArray[i]); // Método que você deve implementar na classe Turma
                            System.out.println("Subturma removida com sucesso.");
                            removida = true;
                            break;
                        }
                    }

                    if (!removida) {
                        System.out.println("Subturma com ID " + idSubTurmaDeleta + " não encontrada.");
                    }
                    break;
                case 5:
                    Turma[] subturmas = turma.getSubturmas();
                    System.out.println("Digite o ID da subturma que deseja entrar:");
                    int idSubTurmas = Integer.parseInt(scanner.nextLine());
                    Turma escolhida = null;
                    for (Turma st : subturmas) {
                        if (st.getID() == idSubTurmas) {
                            escolhida = st;
                            break;
                        }
                    }
                    if (escolhida != null) {
                        menuDeTurma(escolhida); // reusa menu da turma
                    } else {
                        System.out.println("Subturma não encontrada.");
                    }
                    break;


                default:
                    System.out.println("Operação inválida");
                    break;
            }
        }
    }



    public static void imprimirInformacoes(Pessoa pessoa){
        System.out.println("-----Pessoa----");
        System.out.println("CPF: " + pessoa.getCPF());
        System.out.println("Nome: " + pessoa.getNome());
        System.out.println("Nascimento: " + pessoa.getNascimento());
        System.out.println("Email: " + pessoa.getEmail());
        System.out.println("Endereço: " + pessoa.getEndereco());
    }

    public static void imprimirInformacoes(Turma turma){
        System.out.println("\n-----Turma----");
        System.out.println("ID da turma: " + turma.getID());
        System.out.println("Nome da turma:  " + turma.getNome());
        System.out.println("Descrição da turma: " + turma.getDescricao());
        System.out.println("Início da turma: " + turma.getInicio());
        System.out.print("Fim da turma: " + turma.getFim());

    }

    public static void imprimirInformacoes(Atividade atividade){
        System.out.println("-----Atividade----");
        System.out.println("ID: " + atividade.getID());
        System.out.println("Nome: " + atividade.getNome());
        System.out.println("Descrição: " + atividade.getDescricao());
        System.out.println("Inicio: " + atividade.getInicio());
        System.out.println("Fim: " + atividade.getFim());
        System.out.println();
    }

    public static void imprimirInformacoes(Tarefa tarefa){
        System.out.println("------Tarefa------");
        System.out.println("ID: " + tarefa.getID());
        System.out.println("Aluno que recebeu a tarefa: " + tarefa.getAluno().getNome() + " - CPF: " + tarefa.getAluno().getCPF());
        System.out.println("Atividade dada ao aluno: " + tarefa.getAtividade().getDescricao() + " - ID: " + tarefa.getAtividade().getID());
        System.out.println("Nota " + tarefa.getNota());
    }


}
