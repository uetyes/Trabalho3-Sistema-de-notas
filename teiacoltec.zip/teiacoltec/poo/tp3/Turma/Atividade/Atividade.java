package org.teiacoltec.poo.tp3.Turma.Atividade;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import org.teiacoltec.poo.tp3.Excecoes.AtividadeJaAssociadaATurmaException;
import org.teiacoltec.poo.tp3.Turma.Turma;


public class Atividade implements Serializable {
    private static final long serialVersionUID = 1L;

    private int ID;
    private String nome;
    private String descricao;
    private Date inicio;
    private Date fim;
    private float valor;

    public Atividade(int ID, String nome, String descricao, Date inicio, Date fim, float valor){
        this.ID = ID;
        this.nome = nome;
        this.descricao = descricao;
        this.inicio = inicio;
        this.fim = fim;
        this.valor = valor;
    }


    public int getID(){
        return this.ID;
    }

    public String getNome(){
        return this.nome;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public String getDescricao(){
        return this.descricao;
    }

    public void setDescricao(String descricao){
        this.descricao = descricao;
    }

    public Date getInicio(){
        return this.inicio;
    }

    public void setInicio(Date inicio){
        this.inicio = inicio;
    }

    public Date getFim(){
        return this.fim;
    }

    public void setFim(Date fim){
        this.fim = fim;
    }

    public float getValor(){
        return this.valor;
    }

    public void setValor(float valor){
        this.valor = valor;
    }

    public Atividade obtemAtividadePorID(int ID){
        // Retornar o ID que está dentro escrito na atividade. Retorna this, pois é o ID está se referenciando a própria tarefa.
        if(this.getID() == ID){
            return this;
        }
        return null;
    }

    public boolean completa() {
        return (ID > 0
                && nome != null && !nome.isEmpty()
                && descricao != null && !descricao.isEmpty()
                && inicio != null && fim != null
                && valor > 0);
    }

    private static Scanner scanner = new Scanner(System.in);
    private static List<Atividade> listaDeAtividades = new ArrayList<>();

    public static void criarNovaAtividade(){
        Turma turmaSelecionada = Turma.selecionaTurma();
        if (turmaSelecionada == null) {
            System.out.println("Turma não encontrada. Cancelando criação de atividade.");
            return;
        }

        try{
            System.out.println("---Criar nova atividade---");
            System.out.println("ID da atividade:");
            int id = scanner.nextInt();
            scanner.nextLine();

            if (listaDeAtividades.stream().anyMatch(atividade -> Objects.equals(atividade.getID(), id))) {
                System.out.println("Já existe uma atividade com esse ID.");
                return;
            }

            System.out.print("Nome da atividade: ");
            String nome = scanner.nextLine();

            System.out.print("Descricao da atividade: ");
            String descricao = scanner.nextLine();

            System.out.print("Data de inicio da atividade: ");
            Date inicio = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

            System.out.print("Data de finalizacao da atividade: ");
            Date finalizacao = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

            System.out.println("Nota da atividade : ");
            float valor = scanner.nextFloat();

            Atividade atividade = new Atividade(id,nome,descricao,inicio,finalizacao,valor);
            listaDeAtividades.add(atividade);

            turmaSelecionada.associaAtividade(atividade);
        }
        catch (ParseException | AtividadeJaAssociadaATurmaException e) {
            System.out.println("Formato de data inválido. Deve ser: dd/MM/aaaa");
            return;
        }
    }

    public static void listarAtividades(){
        if(listaDeAtividades.isEmpty()){
            System.out.println("Nao se tem nenhuma atividade cadastrado");
            return;
        }

        listaDeAtividades.stream().forEach(atividade -> {
            System.out.print("\n****\n");
            System.out.println("ID da atividade: " + atividade.getID());
            System.out.println("Nome da atividade: " + atividade.getNome());
            System.out.println("Descricao da atividade: " + atividade.getDescricao());
            System.out.println("Data de inicio da atividade: " + atividade.getInicio());
            System.out.println("Data de fim da atvidade: " + atividade.getFim());
            System.out.print("****\n");
        });
    }

    public static Atividade getAtividadePoriID(int id) {
        return listaDeAtividades.stream()
            .filter(atividade -> Objects.equals(atividade.getID(), id))
            .findFirst()
            .orElse(null);
    }



    public static void atualizarAtividade() {
        System.out.println("Digite o ID da atividade que deseja atualiza: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        Atividade atividade = getAtividadePoriID(id);

        if(atividade == null){
            System.out.println("Atividade nao encontrado.");
            return;
        }

        System.out.println("Digite o novo nome da atividade (Enter para nao mudar): ");
        String novoNome = scanner.nextLine();
        if (!novoNome.isBlank()) {
            atividade.setNome(novoNome);
        }

        System.out.println("Digite a nova descricao da atividade (Enter para nao mudar): ");
        String novaDesc = scanner.nextLine();
        if (!novaDesc.isBlank()) {
            atividade.setDescricao(novaDesc);
        }

        System.out.print("Data de inicio da atividade (Enter para nao mudar): ");
        String novaDataInicioStr = scanner.nextLine();
        if (!novaDataInicioStr.isBlank()) {
            try {
                Date novaDataInicio = new SimpleDateFormat("dd/MM/yyyy").parse(novaDataInicioStr);
                atividade.setInicio(novaDataInicio);
            } catch (ParseException e) {
                System.out.println("Data de inicio inválida. Alteração ignorada.");
            }
        }
//int ID, String nome, String descricao, Date inicio, Date fim, float valor
        System.out.print("Data de fim da atividade (Enter para nao mudar): ");
        String novaDataFimStr = scanner.nextLine();
        if (!novaDataFimStr.isBlank()) {
            try {
                Date novaDataFim = new SimpleDateFormat("dd/MM/yyyy").parse(novaDataFimStr);
                atividade.setFim(novaDataFim);
            } catch (ParseException e) {
                System.out.println("Data de fim inválida. Alteração ignorada.");
            }
        }

        System.out.println("Digite o novo valor da atividade (Enter para nao mudar): ");
        float novoValor = scanner.nextFloat();
        scanner.nextLine();
        if (novoValor > 0) {
            atividade.setValor(novoValor);
        }


    }



    public static void deletarAtividade(){
        System.out.println("Digite o ID da atividade que deseja deletar: ");
        int idAtividadeDeletar = scanner.nextInt();
        scanner.nextLine();

        Atividade atividadeParaRemover = getAtividadePoriID(idAtividadeDeletar);
        if(atividadeParaRemover == null){
            System.out.println("Nao existe atividade com esse ID.");
            return;
        }

        listaDeAtividades.remove(atividadeParaRemover);
    }









    /**
     * Salva a lista de atividades em um arquivo usando serialização.
     */
    public static void salvarAtividadeArquivo(String nomeArquivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new java.io.FileOutputStream(nomeArquivo))) {
            oos.writeObject(listaDeAtividades);
            System.out.println("Atividades salvas com sucesso em " + nomeArquivo);
        } catch (java.io.IOException e) {
            System.out.println("Erro ao salvar atividades: " + e.getMessage());
        }
    }


    /**
     * Carrega a lista de atividades de um arquivo usando desserialização.
     */
    @SuppressWarnings("unchecked")
    public static void carregarAtividadeArquivo(String nomeArquivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(nomeArquivo))) {
            Object obj = ois.readObject();
            if (obj instanceof List<?>) {
                listaDeAtividades = (List<Atividade>) obj;
                System.out.println("Atividades carregadas com sucesso de " + nomeArquivo);
            } else {
                System.out.println("O arquivo não contém uma lista de atividades válida.");
            }
        } catch (java.io.IOException | ClassNotFoundException e) {
            System.out.println("Erro ao carregar atividades: " + e.getMessage());
        }
    }










}


