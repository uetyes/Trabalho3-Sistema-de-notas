package org.teiacoltec.poo.tp3.Turma.Atividade;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.*;
import org.teiacoltec.poo.tp3.Pessoa;
import org.teiacoltec.poo.tp3.Turma.ParticipantesDaTurma.Aluno;

public class Tarefa implements Serializable {
    private static final long serialVersionUID = 1L;

    private int ID;
    private Aluno aluno;
    private Atividade atividade;
    private float nota;

    public Tarefa(int ID, Aluno aluno, Atividade atividade, float nota){
        this.ID = ID;
        this.aluno = aluno;
        this.atividade = atividade;
        this.nota = nota;
    }

    public int getID(){
        return this.ID;

    }

    public Aluno getAluno(){
        return this.aluno;
    }

    public Atividade getAtividade(){
        return this.atividade;
    }

    public float getNota(){
        return this.nota;
    }

    public static List<Tarefa> getListaDeTarefas() {
        return listaDeTarefas;
    }

    public Tarefa obtemTarefaPorID(int ID){
        // Retornar o ID que está dentro escrito na tarefa. Retorna this, pois é o ID está se referenciando a própria tarefa
        if(this.getID() == ID){
            return this;
        }
        return null; // Se os ID's forem diferentes, não retorna nada
    }

    public Tarefa[] obtemTarefasDaPessoa(Pessoa pessoa, ArrayList<Tarefa> todasAsTarefas){
        return todasAsTarefas.stream()
            .filter(tarefa -> tarefa.getAluno().equals(pessoa)) // Compara apenas com pessoa e não com suas informações pois aluno herda de pessoa
            .toArray(Tarefa[]::new); // Adicionar a tarefa a lista, pois estou procurando quais tarefas a pessoa faz, não qual tarefa estou fazendo
    }

    public Tarefa[] obtemTarefasDaPessoa(Pessoa pessoa, Date inicio, Date fim, ArrayList<Tarefa> todasAsTarefas) {
        return todasAsTarefas.stream()
            .filter(tarefa -> {
                boolean dentroDoPeriodo = true;
                Date dataInicioAtividade = tarefa.getAtividade().getInicio();
                Date dataFimAtividade = tarefa.getAtividade().getFim();

                if (inicio != null && dataInicioAtividade != null) {
                    if (dataInicioAtividade.before(inicio)) {
                        dentroDoPeriodo = false;
                    }
                }
                if (fim != null && dataFimAtividade != null) {
                    if (dataFimAtividade.after(fim)) {
                        dentroDoPeriodo = false;
                    }
                }

                return tarefa.getAluno().equals(pessoa) && dentroDoPeriodo;
            })
            .toArray(Tarefa[]::new);
    }

    public static Tarefa getTarefaPorCPFDoAluno(String cpf) {
        return listaDeTarefas.stream()
            .filter(tarefa -> tarefa.getAluno() != null && tarefa.getAluno().getCPF().equals(cpf))
            .findFirst()
            .orElse(null);
    }


    private static List<Tarefa> listaDeTarefas = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);


    public static void listarTarefas() {
        if (listaDeTarefas.isEmpty()) {
            System.out.println("Não há nenhuma tarefa cadastrada.");
            return;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

        listaDeTarefas.stream().forEach(tarefa -> {
            Aluno aluno = tarefa.getAluno();
            Atividade atividade = tarefa.getAtividade();

            System.out.println("\n****");
            System.out.println("ID da tarefa: " + tarefa.getID());
            System.out.println("Aluno: " + (aluno != null ? aluno.getNome() : "Aluno não definido"));
            System.out.println("Atividade: " + (atividade != null ? atividade.getNome() : "Atividade não definida"));
            if (atividade != null) {
                System.out.println("Descrição: " + atividade.getDescricao());
                System.out.println("Data de início: " + sdf.format(atividade.getInicio()));
                System.out.println("Data de fim: " + sdf.format(atividade.getFim()));
            }
            System.out.println("Nota da tarefa: " + tarefa.getNota());
            System.out.println("****");
        });
    }

    public static Tarefa getAtividadePoriID (int id){
        return listaDeTarefas.stream()
            .filter(tarefa -> Objects.equals(tarefa.getID(), id))
            .findFirst()
            .orElse(null);
    }

    public static void atualizarTarefa() {
        System.out.print("Digite o ID da tarefa que deseja atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        Tarefa tarefa = getAtividadePoriID(id); // cuidado: o nome está estranho, deveria ser getTarefaPorID
        if (tarefa == null) {
            System.out.println("Tarefa não encontrada.");
            return;
        }

        System.out.print("Digite a nova nota (ou -1 para manter): ");
        float novaNota = scanner.nextFloat();
        scanner.nextLine();

        if (novaNota >= 0) {
            tarefa.nota = novaNota; // direto, ou crie setNota(float)
            System.out.println("Nota atualizada.");
        }
    }

    public static void deletarTarefa() {
        System.out.print("Digite o ID da tarefa que deseja deletar: ");
        int id = scanner.nextInt();
        scanner.nextLine();

        Tarefa tarefaParaRemover = listaDeTarefas.stream()
            .filter(tarefa -> tarefa.getID() == id)
            .findFirst()
            .orElse(null);

        if (tarefaParaRemover == null) {
            System.out.println("Tarefa não encontrada com o ID fornecido.");
            return;
        }

        listaDeTarefas.remove(tarefaParaRemover);
        System.out.println("Tarefa removida com sucesso.");
    }


    public void setNota(float novaNota) {
        this.nota = novaNota;
    }








    /**
     * Salva a lista de tarefas em um arquivo usando serialização.
     */
    public static void salvaTarefaArquivo(String nomeArquivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new java.io.FileOutputStream(nomeArquivo))) {
            oos.writeObject(listaDeTarefas);
            System.out.println("Tarefas salvas com sucesso em " + nomeArquivo);
        } catch (java.io.IOException e) {
            System.out.println("Erro ao salvar tarefas: " + e.getMessage());
        }
    }

    /**
     * Carrega a lista de tarefas de um arquivo usando desserialização.
     */
    @SuppressWarnings("unchecked")
    public static void carregaTarefaArquivo(String nomeArquivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(nomeArquivo))) {
            Object obj = ois.readObject();
            if (obj instanceof List<?>) {
                listaDeTarefas = (List<Tarefa>) obj;
                System.out.println("Tarefas carregadas com sucesso de " + nomeArquivo);
            } else {
                System.out.println("O arquivo não contém uma lista de tarefas válida.");
            }
        } catch (java.io.IOException | ClassNotFoundException e) {
            System.out.println("Erro ao carregar tarefas: " + e.getMessage());
        }
    }






}
