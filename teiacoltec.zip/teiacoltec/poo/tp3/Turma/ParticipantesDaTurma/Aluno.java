package org.teiacoltec.poo.tp3.Turma.ParticipantesDaTurma;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import org.teiacoltec.poo.tp3.Pessoa;



public class Aluno extends Pessoa {
    private String matricula;
    private String curso;

    public Aluno(String CPF, String nome, Date nascimento, String email, String endereco, String matricula, String curso) throws Exception{
        super(CPF, nome, nascimento, email, endereco);
        this.matricula = matricula;
        this.curso = curso;
    }

    private static Scanner scanner = new Scanner(System.in);
    private static List<Aluno> listaDeAlunos = new ArrayList<>();

    public static Aluno getAlunoPorCPF(String cpf) {
        return listaDeAlunos.stream()
            .filter(aluno -> aluno.getCPF() != null && aluno.getCPF().trim().equals(cpf.trim()))
            .findFirst()
            .orElse(null);
    }

    public static Aluno selecionaAlunos() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o CPF do Alunos que deseja selecionar: ");
        String cpf = scanner.nextLine();

        Aluno aluno = listaDeAlunos.stream()
            .filter(a -> a.getCPF() != null && a.getCPF().equals(cpf))
            .findFirst()
            .orElse(null);

        if (aluno == null) {
            System.out.println("Nao existe aluno com esse CPF.");
            return null;
        }

        return aluno;
    }




    public static void criarNovoAluno() throws Exception{
        try{
            System.out.println("---Criar novo aluno---");
            System.out.println("CPF do aluno:");
            String cpf = scanner.nextLine();

            boolean cpfExiste = listaDeAlunos.stream()
                .anyMatch(aluno -> Objects.equals(aluno.getCPF(), cpf));
            if (cpfExiste) {
                System.out.println("Já existe um aluno com esse CPF.");
                return;
            }

            System.out.print("Nome do aluno: ");
            String nome = scanner.nextLine();

            System.out.print("Data de nascimento do aluno: ");
            Date nascimento = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

            System.out.println("E-mail do aluno: ");
            String email = scanner.nextLine();

            System.out.println("Endereco do aluno: ");
            String endereco = scanner.nextLine();

            System.out.println("Matricula do aluno: ");
            String matricula = scanner.nextLine();

            boolean matriculaExiste = listaDeAlunos.stream()
                .anyMatch(aluno -> Objects.equals(aluno.getMatricula(), matricula));
            if (matriculaExiste) {
                System.out.println("Já existe um aluno com esse numero de matricula.");
                return;
            }

            System.out.println("Curso do aluno: ");
            String curso = scanner.nextLine();

            System.out.println("Login do monitor: ");
            String login = scanner.nextLine();


            Aluno aluno = new Aluno(cpf, nome, nascimento, email, endereco, matricula, curso);
            listaDeAlunos.add(aluno);
        }
        catch (ParseException e) {
            System.out.println("Formato de data inválido. Deve ser: dd/MM/aaaa");
            return;
        }
    }

    public static void listarAlunos(){
        if(listaDeAlunos.isEmpty()){
            System.out.println("Nao se tem nenhum aluno cadastrado");
            return;
        }

        listaDeAlunos.stream().forEach(alunos -> {
            System.out.print("\n****\n");
            System.out.println("CPF do aluno: " + alunos.getCPF());
            System.out.println("Nome do aluno: " + alunos.getNome());
            System.out.println("Data de nascimento do aluno: " + alunos.getNascimento());
            System.out.println("E-mail do aluno: " + alunos.getEmail());
            System.out.println("Matricula do aluno: " + alunos.getMatricula());
            System.out.println("Curso do aluno: " + alunos.getFormacaoOuCurso());
            System.out.print("****\n");
        });
    }


    public static void atualizarAlunos() {
        System.out.println("Digite o CPF do aluno que deseja atualiza: ");
        String cpf = scanner.nextLine();

        Aluno alunos = getAlunoPorCPF(cpf);
        
        if(alunos == null){
            System.out.println("Aluno nao encontrado.");
            return;
        }

        System.out.println("Digite o novo nome do aluno (Enter para nao mudar): ");
        String novoNome = scanner.nextLine();
        if (!novoNome.isBlank()) {
            alunos.setNome(novoNome);
        }

        System.out.print("Data de nascimento do aluno (Enter para nao mudar): ");
        String novaDataNascimentoStr = scanner.nextLine();
        if (!novaDataNascimentoStr.isBlank()) {
            try {
                Date novaDataNascimento = new SimpleDateFormat("dd/MM/yyyy").parse(novaDataNascimentoStr);
                alunos.setNascimento(novaDataNascimento);
            } catch (ParseException e) {
                System.out.println("Data de nascimento inválida. Alteração ignorada.");
            }
        }

        System.out.println("Digite o novo e-mail (Enter para nao mudar): ");
        String novoEmail = scanner.nextLine();
        if (!novoEmail.isBlank()) {
            alunos.setEmail(novoEmail);
        }

        System.out.println("Digite o novo endereço (Enter para nao mudar): ");
        String novoEndereco = scanner.nextLine();
        if (!novoEndereco.isBlank()) {
            alunos.setEndereco(novoEndereco);
        }

        System.out.println("Digite a nova matrícula (Enter para nao mudar): ");
        String novaMatricula = scanner.nextLine();
        if (!novaMatricula.isBlank()) {
            alunos.matricula = novaMatricula;
        }

        System.out.println("Digite o novo curso (Enter para não mudar): ");
        String novoCurso = scanner.nextLine();
        if (!novoCurso.isBlank()) {
            alunos.curso = novoCurso;
        }

    }

    public static void deletarAluno(){
        System.out.println("Digite o CPF do aluno que deseja deletar: ");
        String cpfAlunoDeletar = scanner.nextLine();

        Aluno alunoParaRemover = getAlunoPorCPF(cpfAlunoDeletar);
        if(alunoParaRemover == null){
            System.out.println("Nao existe aluno com esse CPF.");
            return;
        }

        listaDeAlunos.remove(alunoParaRemover);
    }



    public String getMatricula() {
        return this.matricula;
    }

    public void serMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getFormacaoOuCurso() {
        return this.curso;
    }

    public void setFormacaoOuCurso(String formacaoOuCurso) {
        this.curso = formacaoOuCurso;
    }
    
    // Verifica se os atributos 'matricula' e 'curso' tem valores dentro delas
    public boolean completa() {
        return (matricula != null && !matricula.isEmpty()
                && curso != null && !curso.isEmpty());
    }

    public void exibirInformacoes(){
        System.out.println("Matrícula: " + matricula);
        System.out.println("Curso: " + curso + "\n");
    }







    /**
     * Salva a lista de alunos em um arquivo usando serialização.
     */
    public static void salvaAlunosArquivo(String nomeArquivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new java.io.FileOutputStream(nomeArquivo))) {
            oos.writeObject(listaDeAlunos);
            System.out.println("Alunos salvos com sucesso em " + nomeArquivo);
        } catch (java.io.IOException e) {
            System.out.println("Erro ao salvar alunos: " + e.getMessage());
        }
    }

    /**
     * Carrega a lista de alunos de um arquivo usando desserialização.
     */
    @SuppressWarnings("unchecked")
    public static void carregaAlunosArquivo(String nomeArquivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(nomeArquivo))) {
            Object obj = ois.readObject();
            if (obj instanceof List<?>) {
                listaDeAlunos = (List<Aluno>) obj;
                System.out.println("Alunos carregados com sucesso de " + nomeArquivo);
            } else {
                System.out.println("O arquivo não contém uma lista de alunos válida.");
            }
        } catch (java.io.IOException | ClassNotFoundException e) {
            System.out.println("Erro ao carregar alunos: " + e.getMessage());
        }
    }








}