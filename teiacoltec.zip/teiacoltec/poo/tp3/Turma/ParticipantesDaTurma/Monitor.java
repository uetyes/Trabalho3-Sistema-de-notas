package org.teiacoltec.poo.tp3.Turma.ParticipantesDaTurma;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import org.teiacoltec.poo.tp3.Pessoa;
public class Monitor extends Pessoa{
    private String matricula;
    private String curso;

    public Monitor(String CPF, String nome, Date nascimento, String email, String endereco, String matricula, String curso) throws Exception{
        super(CPF, nome, nascimento, email, endereco);
        this.matricula = matricula;
        this.curso = curso;
    }

    public boolean completa(){
        return (matricula != null && !matricula.isEmpty()
                && curso != null && !curso.isEmpty());
    }

    public void exibirInformacoes(){
        System.out.println("Matrícula: " + matricula);
        System.out.println("Curso: " + curso + "\n");
    }

    public static Monitor selecionaMonitor() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o CPF do monitor que deseja selecionar: ");
        String cpf = scanner.nextLine();

        Monitor monitor = listaDeMonitores.stream()
            .filter(m -> m.getCPF().equals(cpf))
            .findFirst()
            .orElse(null);

        if (monitor == null) {
            System.out.println("Nao existe monitor com esse CPF.");
            return null;
        }

        return monitor;
    }

    private static Scanner scanner = new Scanner(System.in);
    private static List<Monitor> listaDeMonitores = new ArrayList<>();

    public static void criarNovoMonitor() throws Exception{
        try{
            System.out.println("---Criar novo monitor---");
            System.out.println("CPF do monitor:");
            String cpf = scanner.nextLine();

            boolean cpfExiste = listaDeMonitores.stream()
                .anyMatch(monitor -> Objects.equals(monitor.getCPF(), cpf));
            if (cpfExiste) {
                System.out.println("Já existe um monitor com esse CPF.");
                return;
            }

            System.out.print("Nome do monitor: ");
            String nome = scanner.nextLine();

            System.out.print("Data de nascimento do monitor: ");
            Date nascimento = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

            System.out.println("E-mail do monitor: ");
            String email = scanner.nextLine();

            System.out.println("Endereco do monitor: ");
            String endereco = scanner.nextLine();


            System.out.println("Matricula do monitor: ");
            String matricula = scanner.nextLine();

            boolean matriculaExiste = listaDeMonitores.stream()
                .anyMatch(monitor -> Objects.equals(monitor.getMatricula(), matricula));
            if (matriculaExiste) {
                System.out.println("Já existe um monitor com esse numero de matricula.");
                return;
            }

            System.out.println("Curso do monitor: ");
            String curso = scanner.nextLine();

            Monitor monitor = new Monitor(cpf, nome, nascimento, email, endereco, matricula, curso);
            listaDeMonitores.add(monitor);
        }
        catch (ParseException e) {
            System.out.println("Formato de data inválido. Deve ser: dd/MM/aaaa");   
            return;
        }
    }

    public static void listarMonitores(){
        if(listaDeMonitores.isEmpty()){
            System.out.println("Nao se tem nenhum monitor cadastrado");
            return;
        }

        listaDeMonitores.stream().forEach(monitor -> {
            System.out.print("\n****\n");
            System.out.println("CPF do monitor: " + monitor.getCPF());
            System.out.println("Nome do monitor: " + monitor.getNome());
            System.out.println("Data de nascimento do monitor: " + monitor.getNascimento());
            System.out.println("E-mail do monitor: " + monitor.getEmail());
            System.out.println("Matricula do monitor: " + monitor.getMatricula());
            System.out.println("Curso do monitor: " + monitor.getFormacaoOuCurso());
            System.out.print("****\n");
        });
    }

    public static Monitor getMonitorPorCPF(String cpf){
        return listaDeMonitores.stream()
            .filter(monitor -> Objects.equals(monitor.getCPF(), cpf))
            .findFirst()
            .orElse(null);
    }

    public static void atualizarMonitores() {
        System.out.println("Digite o CPF do aluno que deseja atualiza: ");
        String cpf = scanner.nextLine();

        Monitor monitor = getMonitorPorCPF(cpf);

        if(monitor == null){
            System.out.println("Monitor nao encontrado.");
            return;
        }

        System.out.println("Digite o novo nome do monitor (Enter para nao mudar): ");
        String novoNome = scanner.nextLine();
        if (!novoNome.isBlank()) {
            monitor.setNome(novoNome);
        }

        System.out.print("Data de nascimento do monitor (Enter para nao mudar): ");
        String novaDataNascimentoStr = scanner.nextLine();
        if (!novaDataNascimentoStr.isBlank()) {
            try {
                Date novaDataNascimento = new SimpleDateFormat("dd/MM/yyyy").parse(novaDataNascimentoStr);
                monitor.setNascimento(novaDataNascimento);
            } catch (ParseException e) {
                System.out.println("Data de nascimento inválida. Alteração ignorada.");
            }
        }

        System.out.println("Digite o novo e-mail (Enter para nao mudar): ");
        String novoEmail = scanner.nextLine();
        if (!novoEmail.isBlank()) {
            monitor.setEmail(novoEmail);
        }

        System.out.println("Digite o novo endereço (Enter para nao mudar): ");
        String novoEndereco = scanner.nextLine();
        if (!novoEndereco.isBlank()) {
            monitor.setEndereco(novoEndereco);
        }

        System.out.println("Digite a nova matrícula (Enter para nao mudar): ");
        String novaMatricula = scanner.nextLine();
        if (!novaMatricula.isBlank()) {
            monitor.matricula = novaMatricula;
        }

        System.out.println("Digite o novo curso (Enter para não mudar): ");
        String novoCurso = scanner.nextLine();
        if (!novoCurso.isBlank()) {
            monitor.curso = novoCurso;
        }

    }

    public static void deletarMonitor(){
        System.out.println("Digite o CPF do monitor que deseja deletar: ");
        String cpfMonitorDeletar = scanner.nextLine();

        Monitor monitorParaRemover = getMonitorPorCPF(cpfMonitorDeletar);
        if(monitorParaRemover == null){
            System.out.println("Nao existe monitor com esse CPF.");
            return;
        }

        listaDeMonitores.remove(monitorParaRemover);
    }

    public String getMatricula() {
        return this.matricula;
    }

    public void serMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getFormacaoOuCurso() {
        return this.curso;
    }

    public void setFormacaoOuCurso(String formacaoOuCurso) {
        this.curso = formacaoOuCurso;
    }





    /**
     * Salva a lista de monitores em um arquivo usando serialização.
     */
    public static void salvaMonitorArquivo(String nomeArquivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new java.io.FileOutputStream(nomeArquivo))) {
            oos.writeObject(listaDeMonitores);
            System.out.println("Monitores salvos com sucesso em " + nomeArquivo);
        } catch (java.io.IOException e) {
            System.out.println("Erro ao salvar monitores: " + e.getMessage());
        }
    }

    /**
     * Carrega a lista de monitores de um arquivo usando desserialização.
     */
    @SuppressWarnings("unchecked")
    public static void carregaMonitorArquivo(String nomeArquivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(nomeArquivo))) {
            Object obj = ois.readObject();
            if (obj instanceof List<?>) {
                listaDeMonitores = (List<Monitor>) obj;
                System.out.println("Monitores carregados com sucesso de " + nomeArquivo);
            } else {
                System.out.println("O arquivo não contém uma lista de monitores válida.");
            }
        } catch (java.io.IOException | ClassNotFoundException e) {
            System.out.println("Erro ao carregar monitores: " + e.getMessage());
        }
    }







}


