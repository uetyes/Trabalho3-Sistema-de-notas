package org.teiacoltec.poo.tp3.Turma.ParticipantesDaTurma;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.*;
import org.teiacoltec.poo.tp3.Pessoa;

public class Professor extends Pessoa {
    private String matricula;
    private String formacao;

    public Professor(String CPF, String nome, Date nascimento, String email, String endereco, String matricula, String formacao) throws Exception{
        super(CPF, nome, nascimento, email, endereco);
        this.matricula = matricula;
        this.formacao = formacao;
    }

    // Verifica se os atributos 'matricula' e 'formacao' tem valores dentro delas
    public boolean completa() {
        return (matricula != null && !matricula.isEmpty()
                && formacao != null && !formacao.isEmpty());
    }

    public void exibirInformacoes() {
        System.out.println("Matrícula: " + matricula);
        System.out.println("Formação: " + formacao + "\n");
        System.out.println("Nome: " + getNome());
    }

    public static Professor selecionaProfessor() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Digite o CPF do professor que deseja selecionar: ");
        String cpf = scanner.nextLine();

        Professor professor = listaDeProfessores.stream()
            .filter(prof -> prof.getCPF().equals(cpf))
            .findFirst()
            .orElse(null);

        if (professor == null) {
            System.out.println("Nao existe professor com esse CPF.");
        }

        return professor;
    }

    private static Scanner scanner = new Scanner(System.in);
    private static List<Professor> listaDeProfessores = new ArrayList<>();



    public static Professor getProfessorPorCPF(String cpf) {
        return listaDeProfessores.stream()
            .filter(professor -> Objects.equals(professor.getCPF(), cpf))
            .findFirst()
            .orElse(null);
    }

    public String getMatricula() {
        return this.matricula;
    }

    public void serMatricula(String matricula) {
        this.matricula = matricula;
    }

    public String getFormacaoOuCurso() {
        return this.formacao;
    }

    public void setFormacaoOuCurso(String formacaoOuCurso) {
        this.formacao = formacaoOuCurso;
    }




    /**
     * Salva a lista de professores em um arquivo usando serialização.
     */
    public static void salvaProfessorArquivo(String nomeArquivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new java.io.FileOutputStream(nomeArquivo))) {
            oos.writeObject(listaDeProfessores);
            System.out.println("Professores salvos com sucesso em " + nomeArquivo);
        } catch (java.io.IOException e) {
            System.out.println("Erro ao salvar professores: " + e.getMessage());
        }
    }

    /**
     * Carrega a lista de professores de um arquivo usando desserialização.
     */
    @SuppressWarnings("unchecked")
    public static void carregaProfessorArquivo(String nomeArquivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(nomeArquivo))) {
            Object obj = ois.readObject();
            if (obj instanceof List<?>) {
                listaDeProfessores = (List<Professor>) obj;
                System.out.println("Professores carregados com sucesso de " + nomeArquivo);
            } else {
                System.out.println("O arquivo não contém uma lista de professores válida.");
            }
        } catch (java.io.IOException | ClassNotFoundException e) {
            System.out.println("Erro ao carregar professores: " + e.getMessage());
        }
    }




}

