package org.teiacoltec.poo.tp3.Turma;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Stream;
import org.teiacoltec.poo.tp3.Excecoes.*;
import org.teiacoltec.poo.tp3.Pessoa;
import org.teiacoltec.poo.tp3.Turma.Atividade.Atividade;
import org.teiacoltec.poo.tp3.Turma.Atividade.Tarefa;
import org.teiacoltec.poo.tp3.Turma.ParticipantesDaTurma.*;

public class Turma implements Serializable {
    private static final long serialVersionUID = 1L;

    private int ID;
    private String nome;
    private String descricao;
    private Date inicio;
    private Date fim;
    private Pessoa[] participantes;
    private Turma turma_pai;
    private Turma[] turmas_filha;
    private Atividade[] atividades;
    private Professor[] professores;
    private Aluno[] alunos;
    private Monitor[] monitores;

    public Turma(int ID, String nome, String descricao, Date inicio, Date fim, Turma turma_pai) {
        this.ID = ID;
        this.nome = nome;
        this.descricao = descricao;
        this.inicio = inicio;
        this.fim = fim;
        this.participantes = new Pessoa[0];
        this.turma_pai = turma_pai;
        this.turmas_filha = new Turma[0];
        this.atividades = new Atividade[0];
        this.professores = new Professor[0];
        this.alunos = new Aluno[0];
        this.monitores = new Monitor[0];
    }

    public Turma(int id, String nome, String descricao, Date inicio, Date fim) {
        this.ID = id;
        this.nome = nome;
        this.descricao = descricao;
        this.inicio = inicio;
        this.fim = fim;
        this.participantes = new Pessoa[0];
        this.turmas_filha = new Turma[0];
        this.atividades = new Atividade[0];
        this.professores = new Professor[0];
        this.alunos = new Aluno[0];
        this.monitores = new Monitor[0];

    }

    // Método para receber os dados dos participantes e retorna-los
    public Pessoa[] obtemListaParticipantes() {
        return participantes;
    }

    // Receber a lista de participantes para adicionar membros nela
    public void adicionarParticipante(Pessoa pessoa) throws PessoaJaParticipanteException {
        // Usa Stream para verificar duplicidade de CPF
        boolean jaExiste = Arrays.stream(participantes)
            .anyMatch(p -> pessoa.getCPF().equals(p.getCPF()));
        if (jaExiste) {
            throw new PessoaJaParticipanteException(pessoa);
        }
        // Adiciona a nova pessoa ao array
        Pessoa[] novaPessoa = Arrays.copyOf(participantes, participantes.length + 1);
        novaPessoa[participantes.length] = pessoa;
        this.participantes = novaPessoa;
    }

    // Receber a lista de participantes para remover membros dela
    public void removerParticipante(Pessoa pessoa) throws PessoaNaoEncontradaException {
        // Verifica se existe alguém com o mesmo CPF
        boolean existe = Arrays.stream(participantes)
            .anyMatch(p -> pessoa.getCPF().equals(p.getCPF()));
        if (!existe) {
            throw new PessoaNaoEncontradaException(pessoa);
        }
        // Remove usando Stream e filtra quem não tem o CPF igual ao da pessoa a ser removida
        this.participantes = Arrays.stream(participantes)
            .filter(p -> !pessoa.getCPF().equals(p.getCPF()))
            .toArray(Pessoa[]::new);
    }

    // Método para verificar se a pessoa participa da turma
    public boolean participa(Pessoa pessoa) {
        return Arrays.stream(participantes)
            .anyMatch(p -> pessoa.getCPF().equals(p.getCPF()));
    }

    // Adicionar e armazenar subturmas na turma
    public void associaTurma(Turma subturma) {
        turmas_filha = java.util.stream.Stream.concat(
            Arrays.stream(turmas_filha),
            java.util.stream.Stream.of(subturma)
        ).toArray(Turma[]::new);
    }



    public Turma[] getTurmasFilha() {
        return this.turmas_filha;
    }

    private int quantidadeSubturmas; // quantas subturmas estão no array atualmente

    // getter para subturmas
    public Turma[] getSubturmas() {
        return turmas_filha;  // Retorna o array atual (pode ser vazio, mas nunca nulo)
    }

    public static Turma[] listarSubturmas(Turma turma) {
        if (turma == null) {
            System.out.println("Turma inválida.");
            return null;
        }

        Turma[] subturmas = turma.getSubturmas();

        if (subturmas == null || subturmas.length == 0) {
            System.out.println("Essa turma não possui subturmas associadas.");
            return subturmas;
        }

        System.out.println("Subturmas da turma " + turma.getNome() + ":");
        Arrays.stream(subturmas)
            .filter(Objects::nonNull)
            .forEach(subturma -> 
                System.out.println("ID: " + subturma.getID() + " - Nome: " + subturma.getNome())
            );
        return subturmas;
    }


    // Adicionar as turmas principais, participantes dela e as subturmas dela. Tudo isso faz parte de apenas uma turma toda, como a 203
    public Turma(Turma turma_pai) {
        this.turma_pai = turma_pai;
        this.participantes = new Pessoa[0];
        this.turmas_filha = new Turma[0];
    }


    // A variável 'completa' verifica se todas as informações do objeto professor estão preenchidas
    public Professor[] obtemListaProfessores(boolean completa) {
        return Arrays.stream(professores)
            .filter(professor -> professor.completa() == completa)
            .toArray(Professor[]::new);
    }

    public Aluno[] obtemListaAlunos(boolean completa) {
        return Arrays.stream(alunos)
            .filter(aluno -> aluno.completa() == completa)
            .toArray(Aluno[]::new);
    }

    public Monitor[] obtemListaMonitores(boolean completa) {
        return Arrays.stream(monitores)
            .filter(monitor -> monitor.completa() == completa)
            .toArray(Monitor[]::new);
    }

    public void adicionarAlunos(Aluno aluno) throws PessoaJaParticipanteException {
        // Verifica se o aluno já é participante da turma usando Stream
        boolean jaParticipa = Arrays.stream(participantes)
            .anyMatch(participante -> participante.getCPF().equals(aluno.getCPF()));
        if (jaParticipa) {
            throw new PessoaJaParticipanteException(aluno);
        }

        // Adiciona à lista geral de participantes
        adicionarParticipante(aluno);

        // Adiciona ao array específico de alunos usando Stream
        this.alunos = java.util.stream.Stream.concat(
            Arrays.stream(alunos),
            java.util.stream.Stream.of(aluno)
        ).toArray(Aluno[]::new);
    }

    public void removerAluno(Aluno aluno) throws PessoaNaoEncontradaException {
        // Verifica se o aluno existe na lista da turma (pelo CPF)
        boolean existe = Arrays.stream(alunos)
            .anyMatch(a -> a.getCPF().equals(aluno.getCPF()));
        if (!existe) {
            throw new PessoaNaoEncontradaException(aluno);
        }

        // Remove também da lista de participantes
        removerParticipante(aluno);

        // Cria um novo array sem o aluno usando Stream
        this.alunos = Arrays.stream(alunos)
            .filter(a -> !a.getCPF().equals(aluno.getCPF()))
            .toArray(Aluno[]::new);
    }

    public void adicionarMonitor(Monitor monitor) throws PessoaJaParticipanteException {
        // Verifica se o monitor já é participante da turma usando Stream
        boolean jaParticipa = Arrays.stream(participantes)
            .anyMatch(participante -> participante.getCPF().equals(monitor.getCPF()));
        if (jaParticipa) {
            throw new PessoaJaParticipanteException(monitor);
        }

        // Adiciona à lista geral de participantes
        adicionarParticipante(monitor);

        // Adiciona ao array específico de monitores usando Stream
        this.monitores = java.util.stream.Stream.concat(
            Arrays.stream(monitores),
            java.util.stream.Stream.of(monitor)
        ).toArray(Monitor[]::new);
    }

    public void removerMonitor(Monitor monitor) throws PessoaNaoEncontradaException {
        // Verifica se o monitor existe na lista da turma (pelo CPF)
        boolean existe = Arrays.stream(monitores)
        .anyMatch(m -> m.getCPF().equals(monitor.getCPF()));
        if (!existe) {
            throw new PessoaNaoEncontradaException(monitor);
        }

        // Remove também da lista de participantes
        removerParticipante(monitor);

        // Cria um novo array sem o monitor usando Stream
        this.monitores = Arrays.stream(monitores)
        .filter(m -> !m.getCPF().equals(monitor.getCPF()))
        .toArray(Monitor[]::new);
    }

    public void adicionarProfessor(Professor professor) throws PessoaJaParticipanteException {
        // Verifica duplicidade usando Stream
        boolean jaParticipa = Arrays.stream(participantes)
            .anyMatch(participante -> participante.getCPF().equals(professor.getCPF()));
        if (jaParticipa) {
            throw new PessoaJaParticipanteException(professor);
        }

        // Adiciona na lista geral de participantes
        adicionarParticipante(professor);

        // Adiciona ao array específico de professores usando Stream
        this.professores = java.util.stream.Stream.concat(
            Arrays.stream(professores),
            java.util.stream.Stream.of(professor)
        ).toArray(Professor[]::new);
    }

    public void removerProfessor(Professor professor) throws PessoaNaoEncontradaException {
        // Remove do array de participantes (Pessoa[])
        removerParticipante(professor);

        // Verifica se o professor está no array específico de professores usando Stream
        boolean existe = Arrays.stream(professores)
        .anyMatch(p -> p.getCPF().equals(professor.getCPF()));
        if (!existe) {
            throw new PessoaNaoEncontradaException(professor);
        }

        // Cria um novo array sem o professor usando Stream
        this.professores = Arrays.stream(professores)
        .filter(p -> !p.getCPF().equals(professor.getCPF()))
        .toArray(Professor[]::new);
    }

    // Adicionar atividade para a turma
    public void associaAtividade(Atividade atividade) throws AtividadeJaAssociadaATurmaException {
        // Verifica duplicidade usando Stream
        boolean jaExiste = Arrays.stream(atividades)
            .anyMatch(a -> a.getID() == atividade.getID());
        if (jaExiste) {
            throw new AtividadeJaAssociadaATurmaException(atividade);
        }
        // Adiciona ao array de atividades usando Stream
        this.atividades = java.util.stream.Stream.concat(
            Arrays.stream(atividades),
            java.util.stream.Stream.of(atividade)
        ).toArray(Atividade[]::new);
    }

    public void desassociaAtividade(Atividade atividade) throws AtividadeNaoEncontradaException {
        // Verifica se a atividade existe usando Stream
        boolean existe = Arrays.stream(atividades)
        .anyMatch(a -> a.obtemAtividadePorID(a.getID()).equals(atividade.obtemAtividadePorID(atividade.getID())));
        if (!existe) {
            throw new AtividadeNaoEncontradaException(atividade);
        }

        // Remove a atividade usando Stream
        this.atividades = Arrays.stream(atividades)
        .filter(a -> !a.obtemAtividadePorID(a.getID()).equals(atividade.obtemAtividadePorID(atividade.getID())))
        .toArray(Atividade[]::new);
    }

    // Verificar as atividades da turma
    public Atividade[] obtemAtividadesDaTurma(boolean completa) {
        return Arrays.stream(atividades)
            .filter(atividade -> atividade.completa() == completa)
            .toArray(Atividade[]::new);
    }

    // Verificar as atividades dentro do período
    public Atividade[] obtemAtividadesDaTurma(boolean completa, Date inicio, Date fim) {
        return Arrays.stream(atividades)
            .filter(atividade -> {
                boolean dentroDoPeriodo = true;
                if (inicio != null && atividade.getInicio() != null) {
                    if (atividade.getInicio().before(inicio)) {
                        dentroDoPeriodo = false;
                    }
                }
                if (fim != null && atividade.getFim() != null) {
                    if (atividade.getFim().after(fim)) {
                        dentroDoPeriodo = false;
                    }
                }
                return atividade.completa() == completa && dentroDoPeriodo;
            })
            .toArray(Atividade[]::new);
    }

    public Atividade[] obtemAtividadesDaTurmaCompleta(boolean completa) {
        return Arrays.stream(atividades)
            .filter(atividade -> atividade.completa() == completa)
            .toArray(Atividade[]::new);
    }

    public Atividade[] obtemAtividadesDaTurmaCompleta(boolean completa, Date inicio, Date fim) {
        return Arrays.stream(atividades)
            .filter(atividade -> {
                boolean statusCompativel = atividade.completa() == completa;
                boolean dentroDoIntervalo = true;

                if (inicio != null && atividade.getInicio() != null) {
                    if (atividade.getInicio().before(inicio)) {
                        dentroDoIntervalo = false;
                    }
                }
                if (fim != null && atividade.getFim() != null) {
                    if (atividade.getFim().after(fim)) {
                        dentroDoIntervalo = false;
                    }
                }
                return statusCompativel && dentroDoIntervalo;
            })
            .toArray(Atividade[]::new);
    }
    
    public static Turma getTurmaPorId(int id){
        return Stream.concat(listaDeTurmas.stream(), listaDeSubTurmas.stream())
            .filter(turma -> turma.getID() == id)
            .findFirst()
            .orElse(null);
    }

    public Turma[] obtemTurmasDaPessoa(Pessoa pessoa) {
        ArrayList<Turma> turmaPessoa = new ArrayList<>();

        if (participa(pessoa)) {
            turmaPessoa.add(this); // Adiciona a própria instância da turma (this) a lista, pois a pessoa participa desta turma
        }
        return turmaPessoa.toArray(new Turma[0]);
    }

    private static Scanner scanner = new Scanner(System.in);
    private static List<Turma> listaDeSubTurmas = new ArrayList<>();


    public void criarNovaSubTurma() {
        try {
            System.out.println("---Criar nova subTurma---");
            System.out.println("ID da subTurma:");
            int id = Integer.parseInt(scanner.nextLine());

            boolean jaExiste = listaDeSubTurmas.stream()
                .anyMatch(turma -> turma.getID() == id);
            if (jaExiste) {
                System.out.println("Já existe uma subTurma com esse ID. Escolha outro.");
                return;
            }

            System.out.print("Nome da subTurma: ");
            String nome = scanner.nextLine();

            System.out.print("Descrição: ");
            String descricao = scanner.nextLine();

            System.out.print("Data de Início (dd/MM/aaaa): ");
            Date inicio = new SimpleDateFormat("dd/MM/yyyy").parse(scanner.nextLine());

            Turma novaTurma = new Turma(id, nome, descricao, inicio, fim);
            listaDeSubTurmas.add(novaTurma);

            System.out.print("ID da turma pai que deseja associar: ");
            int idPai = Integer.parseInt(scanner.nextLine());
            Turma turmaPai = getTurmaPorId(idPai);

            if (turmaPai == null) {
                System.out.println("Turma pai não encontrada.");
                return;
            }

            turmaPai.associaTurma(novaTurma);

            novaTurma.turma_pai = turmaPai;

        } catch (ParseException e) {
            System.out.println("Formato de data inválido. Deve ser: dd/MM/aaaa");
        } catch (NumberFormatException e) {
            System.out.println("ID inválido. Deve ser um número inteiro.");
        }
 
    } 

      public void removeSubturma(Turma subturmaParaRemover) {
        if (subturmaParaRemover == null) return;

        Turma[] subturmas = this.getSubturmas();
        boolean encontrou = Arrays.stream(subturmas)
            .anyMatch(sub -> sub != null && sub.equals(subturmaParaRemover));

        if (!encontrou) {
            System.out.println("Subturma não encontrada para remoção.");
            return;
        }

        // Remove a subturma usando Stream e atualiza o array
        this.turmas_filha = Arrays.stream(subturmas)
            .filter(sub -> sub != null && !sub.equals(subturmaParaRemover))
            .toArray(Turma[]::new);
    }

    public ArrayList<Tarefa> tarefas = new ArrayList<>();

    public void adicionaTarefa(Tarefa tarefa) {
        tarefas.add(tarefa);
    }

    public void removeTarefa(Tarefa tarefa) {
        tarefas.remove(tarefa);
    }


    public Tarefa[] obtemTarefas() {
        return tarefas.toArray(new Tarefa[0]);
    }

    private static List<Turma> listaDeTurmas = new ArrayList<>();

    public static Turma selecionaTurma(){
        Scanner scanner = new Scanner(System.in);

        System.out.println("Digite o ID da turma que deseja selecionar");
        int idTurmaSelecionada = scanner.nextInt();

        Turma turmaSelecionada = getTurmaPorId(idTurmaSelecionada);

        return turmaSelecionada;
    }

    public static void listarTurmas(){
        if(listaDeTurmas.isEmpty()){
            System.out.println("Nao se tem nenhuma turma cadastrada");
            return;
        }

        listaDeTurmas.stream().forEach(turma -> {
            System.out.print("\n****\n");
            System.out.println("ID da turma: " + turma.getID());
            System.out.println("Nome da turma: " + turma.getNome());
            System.out.println("Descricao da turma: " + turma.getDescricao());
            System.out.print("****\n");
        });
    }

    public static void listarAtividadesDaTurma() {
        Turma turma = Turma.selecionaTurma();

        if (turma == null) {
            System.out.println("Turma não encontrada.");
            return;
        }

        System.out.print("Deseja listar apenas atividades completas? (s/n): ");
        String resposta = scanner.nextLine().trim().toLowerCase();
        boolean completas = resposta.equals("s");

        Atividade[] atividades = turma.obtemAtividadesDaTurma(completas);

        if (atividades.length == 0) {
            System.out.println("Nenhuma atividade encontrada com esse filtro.");
            return;
        }

        System.out.println("\nAtividades da Turma " + turma.getNome() + ":");
        Arrays.stream(atividades).forEach(atv -> 
            System.out.println(
                "ID: " + atv.getID() +
                " Nome: " + atv.getNome() +
                " Início: " + (atv.getInicio() != null ? atv.getInicio() : "não informado") +
                " Fim: " + (atv.getFim() != null ? atv.getFim() : "não informado") +
                " Valor: " + (atv.getValor() >= 0 ? atv.getValor() : "não informado")
            )
        );
    }

    public void setDataInicio(Date dataInicio){
        this.inicio = dataInicio;
    }

    public void setDataFim(Date dataFim){
        this.fim = dataFim;
    }

    public void setDesc(String descricao){
        this.descricao = descricao;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public int getID(){
        return this.ID;
    }

    public String getNome(){
        return this.nome;
    }

    public String getDescricao(){
        return this.descricao;
    }

    public Date getInicio(){
        return this.inicio;
    }

    public Date getFim(){
        return this.fim;
    }

    public Turma getTurmaPai(){
        return this.turma_pai;
    }



    /**
     * Salva a lista de turmas em um arquivo usando serialização.
     */
    public static void salvarTurmasEmArquivo(String nomeArquivo) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(nomeArquivo))) {
            oos.writeObject(listaDeTurmas);
            System.out.println("Turmas salvas com sucesso em " + nomeArquivo);
        } catch (IOException e) {
            System.out.println("Erro ao salvar turmas: " + e.getMessage());
        }
    }



    /**
     * Carrega a lista de turmas de um arquivo usando desserialização.
     */

    @SuppressWarnings("unchecked")
    public static void carregarTurmasDeArquivo(String nomeArquivo) {
        try (ObjectInputStream ois = new ObjectInputStream(new java.io.FileInputStream(nomeArquivo))) {
            Object obj = ois.readObject();
            if (obj instanceof List<?>) {
                listaDeTurmas = (List<Turma>) obj;
                System.out.println("Turmas carregadas com sucesso de " + nomeArquivo);
            } else {
                System.out.println("O arquivo não contém uma lista de turmas válida.");
            }
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Erro ao carregar turmas: " + e.getMessage());
        }
    }




}
